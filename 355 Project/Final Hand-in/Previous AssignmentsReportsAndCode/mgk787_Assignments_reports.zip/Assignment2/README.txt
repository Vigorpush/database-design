


Steps to run my Assignment 2 database through the provided sql scripts.

1. Download the submitted Assignment2.zip file and unzipped it on your local directory
2. Be sure you to be in ./Assignment2
3. Connect to a PostgresSQL database server
4. execute the following command 
    
          \i 'Assignment2.sql'

This script will run six other sql script files:

\i 'C355A11.sql'
\i 'C355A12.sql'
\i 'C355A13.sql'
\i 'C355A21.sql'
\i 'C355A22.sql'
\i 'C355A23.sql'

This will buildup the database from zero up to the state it's currently on my account university server.