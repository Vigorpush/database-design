-- Name : Mohamed Kassem
-- NSID: mgk787
-- Student no.: 11129292
-- Assignment 2 (Part 3)
-- File Name: C355A23.sql



-- please, read the report for more explanantion.

-- Test MuseumLocationsView data 
SELECT * FROM MuseumLocationsView;
-- Test ExhibitionsView data 
SELECT * FROM ExhibitionsView;

-- Test ExhibitionsLocationView data 
SELECT * FROM ExhibitionsLocationView;

-- Test ExhibitionsCollectionView data 
SELECT * FROM ExhibitionsCollectionView;

-- Test ItemsLocationView data 
SELECT * FROM ItemsLocationView;


-- Test LocationsConnectionsView data 
SELECT * FROM LocationsConnectionsView;


-- Test MuseumLocationsStateview data 
SELECT * FROM MuseumLocationsStateview;

-- Test ItemsOwnershipViewdata 
SELECT * FROM ItemsOwnershipView;

-- Test WorksColorsView data 
SELECT * FROM WorksColorsView;