-- Name : Mohamed Kassem
-- NSID: mgk787
-- Student no.: 11129292
-- Assignment 2 (Part 1)
-- File Name: C355A21.sql


-- *********** START OF CHANGES ON ASSIGNMENT 1 DATABASE *********

-- *********** PARTY A: Ensure you have a good database to start with. *****


DROP TABLE IF EXISTS ExhibitionsLocation CASCADE;
DROP VIEW IF EXISTS ExhibitionsLocationView CASCADE;
DROP VIEW IF EXISTS LocationsAvailabilityView CASCADE;
DROP DOMAIN IF EXISTS MinNumWorks CASCADE;
DROP DOMAIN IF EXISTS itemStartdate CASCADE;
DROP DOMAIN IF EXISTS itemEnddate CASCADE;



-- Recall from Assignment 1: The following is a schematic diagram of my museum structure 

--           50m        50m
--      o----------o-----------o
--      |          /   Lobby   / 20m --> EXIT
--      |          |           |
--      |          o--/-----/--0
--      |          |     |     |
--      |          |  A  |  B  |
-- 150m |  Storage |     /     | 65m
--      |          |     |     |
--      |          |     |     |
--      |          |--/--o--/--o
--      |          | 25m   25m |
--      |          |           |
--      |          |     C     | 65m
--      |          |           |
--      |          |           |
--      o----------o-----------o 

-- Add a new coloum (i.e attribute ML_MinNumWorks) to the MuseumLocations table (Read comments in my report).

-- First, create a new domain for the new attribute
CREATE DOMAIN MinNumWorks AS SMALLINT CHECK (VALUE >=0);
-- Add ML_MinNumWorks attribute to MuseumLocations table.
ALTER TABLE MuseumLocations
 	ADD ML_MinNumWorks MinNumWorks;
	
-- Recreate MuseumLocationsView (Read comments in my report).
CREATE OR REPLACE VIEW MuseumLocationsView
	AS SELECT ML_LocationName, ML_AreaSquareMeter, ML_NumOfDoors, ML_MaxNumWorks, ML_MinNumWorks
		FROM MuseumLocations;

UPDATE MuseumLocationsView
SET ML_MinNumWorks=0, ML_MaxNumWorks=600
	WHERE ML_LocationName='Storage';

UPDATE MuseumLocationsView
SET ML_MinNumWorks=2, ML_MaxNumWorks=4
	WHERE ML_LocationName='Lobby';

UPDATE MuseumLocationsView
SET ML_MinNumWorks=7, ML_MaxNumWorks=16
	WHERE ML_LocationName IN ('Gallery_A', 'Gallery_B');

UPDATE MuseumLocationsView
SET ML_MinNumWorks=14, ML_MaxNumWorks=24
	WHERE ML_LocationName= 'Gallery_C';




-- Create a new ExhibitionLocation table (Read comments in my report)
CREATE TABLE ExhibitionsLocation (
	EXL_ExhName ExhName,
	EXL_ExhLocation ExhLocation,
	
-- This table can allow an exhibition to be in multiple locations
	FOREIGN KEY (EXL_ExhName)
		REFERENCES Exhibitions (EX_ExhName ) 
		ON UPDATE CASCADE 
		ON DELETE CASCADE


	);

-- Create a VIEW for  ExhibitionsLocation table (Read comments in my report)
-- .. This view allows insertion, updates and deletes (Read/Write View)
CREATE VIEW ExhibitionsLocationView
	AS SELECT EXL_ExhName, EXL_ExhLocation
	FROM ExhibitionsLocation
	;
-- These are the same exhibition i had in Assignment 1, nothing change.
INSERT INTO ExhibitionsLocationView (EXL_ExhName, EXL_ExhLocation)
	VALUES ('Still life in European Art', 'Gallery_A'),
	       ('A Glimpse from the Life of the Christ: Sacred Arts', 'Gallery_B'),
	       ('The Woven Bridges: Classical Textiles', 'Gallery_C');


-- Drop the attributes EX_ExhLocation from Exhibitions table (Read comments in my report for WHY?).
-- This is a necessary drop since we need only one attribute to record Exhibitions location in one table.
ALTER TABLE Exhibitions
DROP COLUMN EX_ExhLocation CASCADE;

-- Dropping EX_ExhLocation from Exhibitions table will drop four dependent views:
-- exhibitionsview, itemsavailiabiltynewexhibitions, exhibitionslistpublicview and
-- exhibitionsadditionalworksview. (Read comments in my report for WHY?).

-- Recreate ExhibitionsView  VIEW
CREATE OR REPLACE VIEW ExhibitionsView
	AS SELECT EX_ExhName, EX_ExhStartdate, EX_ExhEnddate, EX_ExhDescription
	FROM Exhibitions
	;

-- Recreate ItemsAvailiabiltyNewExhibitions VIEW
-- Recall: from Assignment 1, Items which will be available immediately for current use (i.e. not in any running (active) exhibitions), will be listed with today's date
-- (i.e. the day you will be running my code on an postgresSQL server)
CREATE OR REPLACE VIEW ItemsAvailiabiltyNewExhibitions
	AS 
		(SELECT mcv.MC_ItemAlphaKey, mcv.MC_ItemNumKey, mcv.MC_ItemName, mcv.MC_Type, mcv.MC_SubType, CAST (now() AS DATE) AS IAnex_AvailableDate
		FROM MuseumCollectionView mcv, ItemsLocationView Ilv
		WHERE mcv.MC_ItemAlphaKey= Ilv.ITL_ItemAlphaKey AND mcv.MC_ItemNumKey= Ilv.ITL_ItemNumKey AND Ilv.ITL_ItemLocation='Storage'
		) 
	UNION (
		SELECT mcv.MC_ItemAlphaKey, mcv.MC_ItemNumKey, mcv.MC_ItemName, mcv.MC_Type, mcv.MC_SubType, exv.EX_ExhEnddate AS IAnex_AvailableDate
		FROM MuseumCollectionView mcv, ExhibitionsView exv, ExhibitionsCollectionView ecxv
		WHERE mcv.MC_ItemAlphaKey= ecxv.EXC_ItemAlphaKey AND mcv.MC_ItemNumKey= ecxv.EXC_ItemNumKey AND ecxv.EXC_ExhName=exv.EX_ExhName
		) 

	ORDER BY IAnex_AvailableDate, MC_Type, MC_SubType;



-- Recreate ExhibitionsListPublicView VIEW
CREATE OR REPLACE VIEW ExhibitionsListPublicView
	AS SELECT exlv.EXL_ExhName, exlv.EXL_ExhLocation,(SELECT COUNT(*)
													FROM ExhibitionsCollectionView excv
													WHERE excv.EXC_ExhName = exv.EX_ExhName)
													AS EX_NumOfWorks, exv.EX_ExhDescription
	FROM ExhibitionsLocationView exlv, ExhibitionsView exv
	WHERE exlv.EXL_ExhName=exv.EX_ExhName;

-- Recreate ExhibitionsAdditionalWorksView VIEW
CREATE OR REPLACE VIEW ExhibitionsAdditionalWorksView
	AS SELECT elpv.EXL_ExhName, (mlv.ML_MaxNumWorks-elpv.EX_NumOfWorks) AS NumOfAdditionalWork
	FROM  MuseumLocationsView mlv, ExhibitionsListPublicView  elpv
	WHERE elpv.EXL_ExhLocation=mlv.ML_LocationName
	;

-- Added two  attributes: ITL_Startdate and ITL_Enddate to ItemsLocation table.
-- First, we create a two new domains for the new attribute
CREATE DOMAIN itemStartdate AS DATE CHECK (VALUE >= '1990-07-01');
CREATE DOMAIN itemEnddate AS DATE CHECK (VALUE >= '1990-07-01');

ALTER TABLE ItemsLocation
	ADD ITL_Startdate itemStartdate,
	ADD ITL_Enddate  itemEnddate;

-- Recreate the ItemsLocationView after altering the ItemsLocation table.
CREATE OR REPLACE VIEW ItemsLocationView
	AS SELECT ITL_ItemAlphaKey, ITL_ItemNumKey, ITL_ItemLocation, ITL_Startdate, ITL_Enddate
	FROM ItemsLocation
	ORDER BY ITL_ItemAlphaKey, ITL_ItemNumKey, ITL_Startdate
	;

-- Deleting everything from ItemsLocationsView (Read comments in my report for WHY?)
-- Note: We will insert data in this view from the begining.
-- Note also, we only clear the data not drop the table.
DELETE FROM ItemsLocationView;


-- As per Assignment 1, all items in the museum are initially stored  in the Storage location.
-- Note the startdate is the same as the ItemAcquisitionDate and Enddate is 2099-12-31 (Read report for more details).
INSERT INTO ItemsLocationView (ITL_ItemAlphaKey, ITL_ItemNumKey, ITL_ItemLocation, ITL_Startdate, ITL_Enddate)
	SELECT mcv.MC_ItemAlphaKey, mcv.MC_ItemNumKey, 'Storage', mcv.MC_ItemAcquisitionDate, '2099-12-31'
	FROM MuseumCollection mcv;


-- INSERT two special items in the Lobby
-- Assume their insertion date is 2 months after their date of aquisition.
-- We will place these two items PNTG 1001 and PNTG 1003
-- We have to first update the current end date of these two special items (which are currently still in Storage) to be the same as 
-- the starting date they will be placed in the Lobby. 
UPDATE ItemsLocationView
SET ITL_Enddate=mcv.MC_ItemAcquisitionDate+ INTERVAL '2 month'
FROM  MuseumCollectionView mcv
WHERE mcv.MC_ItemAlphaKey=ITL_ItemAlphaKey AND mcv.MC_ItemNumKey= ITL_ItemNumKey AND ITL_ItemAlphaKey='PNTG' AND ITL_ItemNumKey IN (1001, 1003);


INSERT INTO ItemsLocationView (ITL_ItemAlphaKey, ITL_ItemNumKey, ITL_ItemLocation, ITL_Startdate, ITL_Enddate)
	SELECT mcv.MC_ItemAlphaKey, mcv.MC_ItemNumKey, 'Lobby', mcv.MC_ItemAcquisitionDate+ INTERVAL '2 month', CAST (now() AS DATE)
	FROM MuseumCollection mcv
	WHERE (MC_ItemAlphaKey='PNTG' AND MC_ItemNumKey IN (1001, 1003));


-- trigger_ItemInsertedInExhibition() is the trigger function. This function is executed 
-- AFTER any INSERT in to ExhibitionsCollection table OR view.
CREATE OR REPLACE FUNCTION trigger_ItemInsertedInExhibition() RETURNS TRIGGER AS
$BODY$
    BEGIN
        
		-- IF the newly INSERTED item in ExhibitionsCollectionView already exists in any of the rows of the ItemsLocationView, then firstly
		-- update the End date of this item to be the same as starting date of the Exhibition in which this same item is place in. 
		UPDATE ItemsLocationView
		SET ITL_Enddate=foo.EX_ExhStartdate
		FROM ( SELECT	NEW.EXC_ItemAlphaKey,
       					NEW.EXC_ItemNumKey,
      					exlv.EXL_ExhLocation,
       					exv.EX_ExhStartdate,
      					exv.EX_ExhEnddate
    		FROM exhibitionslocationView exlv, exhibitionsView exv
    		WHERE exlv.EXL_ExhName = NEW.EXC_ExhName AND exv.EX_ExhName = NEW.EXC_ExhName) AS foo (EXC_ItemAlphaKey, EXC_ItemNumKey, EXL_ExhLocation, EX_ExhStartdate, EX_ExhEnddate)
				WHERE ITL_ItemAlphaKey=foo.EXC_ItemAlphaKey AND ITL_ItemNumKey=foo.EXC_ItemNumKey AND ITL_ItemAlphaKey=NEW.EXC_ItemAlphaKey AND ITL_ItemNumKey=NEW.EXC_ItemNumKey AND ITL_ItemLocation='Storage' AND ITL_Enddate= (SELECT MAX (ITL_Enddate) FROM ItemsLocationView
																																																							WHERE ITL_ItemAlphaKey= NEW.EXC_ItemAlphaKey AND ITL_ItemNumKey= NEW.EXC_ItemNumKey AND ITL_ItemLocation='Storage'); 
		 
		-- INSERT the newly added item in to the ItemsLocationView with a starting date and ending dates equal to that of the Exhibition,
		-- in which the item is place in.
		INSERT INTO ItemsLocationView (ITL_ItemAlphaKey, ITL_ItemNumKey, ITL_ItemLocation, ITL_Startdate, ITL_Enddate)
      		SELECT  NEW.EXC_ItemAlphaKey,
       				NEW.EXC_ItemNumKey,
      				exlv.EXL_ExhLocation,
       				exv.EX_ExhStartdate,
      				exv.EX_ExhEnddate
    		FROM exhibitionslocationView exlv, exhibitionsView exv
    		WHERE exlv.EXL_ExhName = NEW.EXC_ExhName AND exv.EX_ExhName = NEW.EXC_ExhName;
   
		RETURN NULL;
    END;
$BODY$
	LANGUAGE plpgsql;

-- Create an AFTER INSERT TRIGGER named trigger_ItemInsertedInExhibition.
CREATE TRIGGER trigger_ItemInsertedInExhibition
  AFTER INSERT  
  ON ExhibitionsCollection
  FOR EACH ROW
  EXECUTE PROCEDURE trigger_ItemInsertedInExhibition();


-- Deleting everything from ExhibitionsCollectionView
-- Note: We will insert data in this from the beginning.
-- Note also, we only clear the data not drop the table.
DELETE FROM ExhibitionsCollectionView;



-- Recall from Assignment 1: One exhibition should contain 9 works, one 10 works, and one 16 works.
-- Placing Items in Exhibition 1: A Glimpse from the Life of the Christ: Sacred Arts (9 Items inserted).

INSERT INTO ExhibitionsCollectionView(EXC_ExhName, EXC_ItemAlphaKey, EXC_ItemNumKey)
	SELECT 'A Glimpse from the Life of the Christ: Sacred Arts', MC_ItemAlphaKey, MC_ItemNumKey 
	FROM MuseumCollection
	WHERE (MC_ItemAlphaKey='PNTG' AND MC_ItemNumKey IN (1002, 1008, 1014, 1018, 1022, 1024)) OR
		  (MC_ItemAlphaKey='TXTL' AND MC_ItemNumKey=2001) OR
		  (MC_ItemAlphaKey='SCLP' AND MC_ItemNumKey IN (3009, 3010));


-- Placing Items in Exhibition 2: Still life in European Art (10 Items inserted).

INSERT INTO ExhibitionsCollectionView(EXC_ExhName, EXC_ItemAlphaKey, EXC_ItemNumKey)
	SELECT 'Still life in European Art', MC_ItemAlphaKey, MC_ItemNumKey 
	FROM MuseumCollection
	WHERE (MC_ItemAlphaKey='PNTG' AND MC_ItemNumKey IN (1007, 1020, 1021, 1025, 1026, 1027, 1028, 1029, 1030, 1031));



-- Placing Items in Exhibition 3: The Woven Bridges: Classical Textiles (16 Items inserted).

INSERT INTO ExhibitionsCollectionView(EXC_ExhName, EXC_ItemAlphaKey, EXC_ItemNumKey)
	SELECT 'The Woven Bridges: Classical Textiles', MC_ItemAlphaKey, MC_ItemNumKey 
	FROM MuseumCollection
	WHERE (MC_ItemAlphaKey='TXTL' AND MC_ItemNumKey IN (2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2012, 2013, 2014, 2015, 2016, 2017, 2018));

-- Uncomment the below command to test trigger_ItemInsertedInExhibition
--SELECT * FROM ItemsLocationView; 


-- *********** END OF CHANGES ON ASSIGNMENT 1 DATABASE *********

-- Create a new LocationsAvailabilityView
CREATE VIEW LocationsAvailabilityView
AS SELECT exlv.EXL_ExhLocation, mlv.ML_MaxNumWorks, exv.EX_ExhStartdate, exv.EX_ExhEnddate
	FROM MuseumLocationsView mlv, ExhibitionsView exv, ExhibitionsLocationView exlv
	WHERE exlv.EXL_ExhLocation=mlv.ML_LocationName AND exlv.EXL_ExhName=exv.EX_ExhName
;

-- An AFTER INSERT TIGGER function trigger_newExhibitionInserted() (Read Report for more details)
CREATE OR REPLACE FUNCTION trigger_newExhibitionInserted() RETURNS TRIGGER AS
$BODY$
    
    BEGIN
                
        INSERT INTO ExhibitionsLocationView (EXL_ExhName, EXL_ExhLocation)
		SELECT NEW.EX_ExhName, lav.EXL_ExhLocation
		FROM LocationsAvailabilityView lav, ExhibitionsView exv
		WHERE lav.EX_ExhEnddate+5=exv.EX_ExhStartdate AND NEW.EX_ExhName=exv.EX_ExhName;
		RETURN NULL;
    END;
$BODY$
	LANGUAGE plpgsql;

-- Create an AFTER INSERT TRIGGER named trigger_newExhibitionInserted ((Read Report for more details))
-- This trigger fires up AFTER every INSERT in to the ExhibitionsView
CREATE TRIGGER trigger_newExhibitionInserted
  AFTER INSERT  
  ON Exhibitions
  FOR EACH ROW
  EXECUTE PROCEDURE trigger_newExhibitionInserted();



-- An exhibit of 8 works, that will go into the first (small) gallery available where it fits between the suggested minimum and maximum number of works. 
-- This exhibit will be on display for 4 months
INSERT INTO ExhibitionsView (EX_ExhName, EX_ExhStartdate, EX_ExhEnddate, EX_ExhDescription) 
	SELECT 'English Clocks: The Frick Collection', lav.EX_ExhEnddate+5, lav.EX_ExhEnddate+5+ INTERVAL '4 month', 'Samuel Kress was a businessman and philanthropist, with his fortune, Kress amassed one of the most significant collections of Italian Renaissance and European artwork assembled in the 20th century. Madonna and Child is one of the collections by Smaul Kress that portrayed the life of Virign Mary and her Child Jesus Christ'
	FROM LocationsAvailabilityView lav
		WHERE lav.ML_MaxNumWorks>=8 AND lav.EX_ExhEnddate = (SELECT MIN (lav.EX_ExhEnddate) FROM LocationsAvailabilityView lav) ;


-- An exhibit of 9 works that will go into the next (small) gallery available where it fits between the suggested minimum and maximum number of works. 
-- This exhibit will be on display for 5 month
INSERT INTO ExhibitionsView (EX_ExhName, EX_ExhStartdate, EX_ExhEnddate, EX_ExhDescription) 
	SELECT 'Madonna and Child: Samuel Kress Collection', lav.EX_ExhEnddate+5, lav.EX_ExhEnddate+5+ INTERVAL '5 month', 'The Frick collection features some of the best made Clocks in the World. This exhibition presents a different collection of English made clocks made in the period between the 16th and 17th century.'
		FROM LocationsAvailabilityView lav
	WHERE lav.ML_MaxNumWorks>=9 AND lav.EX_ExhEnddate = (SELECT MIN (lav.EX_ExhEnddate) FROM LocationsAvailabilityView lav
																WHERE lav.EX_ExhEnddate > (SELECT MIN (lav.EX_ExhEnddate) FROM LocationsAvailabilityView lav)) ;

-- An exhibit of 18 works that will go into the first (large) gallery available where it fits between the suggested minimum and maximum number of works.
-- This exhibit will be on display for 3 months.
INSERT INTO ExhibitionsView (EX_ExhName, EX_ExhStartdate, EX_ExhEnddate, EX_ExhDescription) 
	SELECT 'La beauté de la Campagne: Best 18 landscape paintings', lav.EX_ExhEnddate+5, lav.EX_ExhEnddate+5+ INTERVAL '3 month', 'The exhibition presents the best of the Europian landscape paintings with special focus on the Europian Country side.'
		FROM LocationsAvailabilityView lav
	WHERE lav.ML_MaxNumWorks>=18;


-- Placing Items in first new Exhibition: Madonna and Child: Samuel Kress Collection (8 Items inserted).
INSERT INTO ExhibitionsCollectionView(EXC_ExhName, EXC_ItemAlphaKey, EXC_ItemNumKey)
	SELECT 'Madonna and Child: Samuel Kress Collection', MC_ItemAlphaKey, MC_ItemNumKey 
	FROM MuseumCollection
	WHERE (MC_ItemAlphaKey='PNTG' AND MC_ItemNumKey IN (1067, 1068, 1069, 1070, 1071, 1072, 1073, 1074)); --107


-- Placing Items in second new Exhibition: English Clocks: The Frick Collection (9 Items inserted).
INSERT INTO ExhibitionsCollectionView(EXC_ExhName, EXC_ItemAlphaKey, EXC_ItemNumKey)
	SELECT 'English Clocks: The Frick Collection', MC_ItemAlphaKey, MC_ItemNumKey 
	FROM MuseumCollection
	WHERE (MC_ItemAlphaKey='CLCK' AND MC_ItemNumKey IN (4001, 4002, 4003, 4004, 4005, 4006, 4007, 4008, 4009));


-- Placing Items in third new Exhibition: La beauté de la Campagne: Best 18 landscape paintings (18 Items inserted).
INSERT INTO ExhibitionsCollectionView(EXC_ExhName, EXC_ItemAlphaKey, EXC_ItemNumKey)
	SELECT 'La beauté de la Campagne: Best 18 landscape paintings', MC_ItemAlphaKey, MC_ItemNumKey 
	FROM MuseumCollection
	WHERE (MC_ItemAlphaKey='PNTG' AND MC_ItemNumKey IN (1010, 1011, 1012, 1016, 1040, 1041, 1042, 1043, 1044, 1045, 1046, 1047, 1048, 1049, 1050, 1051, 1052, 1053));



