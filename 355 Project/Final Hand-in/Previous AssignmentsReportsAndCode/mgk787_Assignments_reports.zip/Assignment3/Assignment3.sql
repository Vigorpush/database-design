-- Name : Mohamed Kassem
-- NSID: mgk787
-- Student no.: 11129292
-- Assignment 3 script 
-- File Name: main.sql


-- Running script.

\pset pager off
\pset format wrapped
\pset border 3

\i 'C355A31.sql' -- This script initially runs Assignment2.sql script
\i 'C355A32.sql'
\i 'C355A33.sql'
\i 'C355A34.sql'
\i 'C355A35.sql'