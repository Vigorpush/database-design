-- Name : Mohamed Kassem
-- NSID: mgk787
-- Student no.: 11129292
-- Assignment 2 script 
-- File Name: main.sql


-- Running script.

\pset pager off
\pset format wrapped
\pset border 3

\i 'C355A11.sql'
\i 'C355A12.sql'
\i 'C355A13.sql'
\i 'C355A21.sql'
\i 'C355A22.sql'
