-- Name : Mohamed Kassem
-- NSID: mgk787
-- Student no.: 11129292
-- Assignment 1 (Part 1)
-- File Name: C355A11.sql


-- Dropping All Domains, Tables and View IF they exits and 
-- starts over.


---- **** DROPPING ALL VIEWS **** ----

	DROP VIEW IF EXISTS MuseumLocationsView CASCADE;
	DROP VIEW IF EXISTS LocationsConnectionsView CASCADE;
	DROP VIEW IF EXISTS MuseumcollectionView CASCADE;
	DROP VIEW IF EXISTS WorksMediumView CASCADE;
	DROP VIEW IF EXISTS ItemsLocationView CASCADE;
	DROP VIEW IF EXISTS ExhibitionsView CASCADE;
	DROP VIEW IF EXISTS ExhibitionsCollectionView CASCADE;
	DROP VIEW IF EXISTS ItemsInStoragePrivateView CASCADE;
	DROP VIEW IF EXISTS ExhibitionsListPublicView CASCADE;
	DROP VIEW IF EXISTS ExhibitionsCollectionInfoPublicView CASCADE;
	DROP VIEW IF EXISTS ItemsAvailiabiltyNewExhibitions CASCADE;
	


---- **** DROPPING ALL TABLES **** ----

	DROP TABLE IF EXISTS MuseumLocations CASCADE;
    DROP TABLE IF EXISTS LocationsConnections CASCADE;
	DROP TABLE IF EXISTS Museumcollection CASCADE;
	DROP TABLE IF EXISTS WorksMedium CASCADE;
	DROP TABLE IF EXISTS ItemsLocation CASCADE;
	DROP TABLE IF EXISTS Exhibitions CASCADE;
	DROP TABLE IF EXISTS ExhibitionsCollection CASCADE;
	

---- **** DROPPING ALL DOMAINS **** ----

	DROP DOMAIN IF EXISTS LocationName CASCADE;
	DROP DOMAIN IF EXISTS MaxNumWorks CASCADE;
	DROP DOMAIN IF EXISTS AreaSquareMeter CASCADE;
	DROP DOMAIN IF EXISTS NumOfDoors CASCADE;
	DROP DOMAIN IF EXISTS ConnectedTo CASCADE;


	DROP DOMAIN IF EXISTS ItemAlphaKey CASCADE;
	DROP DOMAIN IF EXISTS ItemNumKey CASCADE;
	DROP DOMAIN IF EXISTS ItemName CASCADE;
	DROP DOMAIN IF EXISTS ItemLocation CASCADE;
	DROP DOMAIN IF EXISTS Type CASCADE;
	DROP DOMAIN IF EXISTS Subtype CASCADE;
	DROP DOMAIN IF EXISTS ItemSource CASCADE;
	DROP DOMAIN IF EXISTS ItemComplYear CASCADE;
	DROP DOMAIN IF EXISTS ItemAcquisitionDate CASCADE;
	DROP DOMAIN IF EXISTS ItemInsuranceValue CASCADE;
	DROP DOMAIN IF EXISTS ItemDescription CASCADE;
	DROP DOMAIN IF EXISTS ItemMedium CASCADE;

	DROP DOMAIN IF EXISTS ExhName CASCADE;
	DROP DOMAIN IF EXISTS ExhStartdate CASCADE;
	DROP DOMAIN IF EXISTS ExhEnddate CASCADE;
	DROP DOMAIN IF EXISTS ExhLocation CASCADE;
	DROP DOMAIN IF EXISTS ExhDescription CASCADE;

    
-------------- ******  Museum's Locations Database**** ----------


-- Domains for MuseumLocations and LocationsConnections Table.

	CREATE DOMAIN LocationName AS CHAR (15) NOT NULL DEFAULT '';
	CREATE DOMAIN MaxNumWorks AS SMALLINT CHECK (VALUE <= 1000);
	CREATE DOMAIN AreaSquareMeter AS SMALLINT CHECK (VALUE > 1); -- Area must be > 1 square-meter.
	CREATE DOMAIN NumOfDoors AS SMALLINT CHECK (VALUE > 0);
	CREATE DOMAIN ConnectedTo AS CHAR (15) NOT NULL DEFAULT '';


-- The below tables record all the basic information regarding the different 
-- .. locations in the museum (i.e. their names, size, numOfDoor and how they're connect together) 
	
	CREATE TABLE MuseumLocations (
		ML_LocationName LocationName,
		ML_AreaSquareMeter AreaSquareMeter,
		ML_NumOfDoors NumOfDoors,
		ML_MaxNumWorks MaxNumWorks,

		PRIMARY KEY(ML_LocationName)
	);


-- Record the connection between different museum locations.
	CREATE TABLE LocationsConnections (
		LC_LocationName LocationName,
		LC_ConnectedTo ConnectedTo,

		FOREIGN KEY (LC_LocationName)
			REFERENCES MuseumLocations (ML_LocationName) 
			ON UPDATE CASCADE 
			ON DELETE CASCADE
	);

-------------- ****  Museum Collection Database **** ----------


-- Domains for MuseumCollection, WorksMedium and ItemsLocation Tables.

	CREATE DOMAIN ItemAlphaKey AS CHAR (4) NOT NULL;
	CREATE DOMAIN ItemNumKey AS SMALLINT NOT NULL;
	CREATE DOMAIN ItemName AS TEXT DEFAULT 'No Name';
	CREATE DOMAIN ItemLocation AS CHAR (50) NOT NULL;
	CREATE DOMAIN Type AS CHAR (15) NOT NULL;
	CREATE DOMAIN SubType AS CHAR (15) NOT NULL;
	CREATE DOMAIN ItemSource AS CHAR (50) DEFAULT 'UnKnown';
	CREATE DOMAIN ItemComplYear AS SMALLINT CHECK (VALUE > 1000);
	CREATE DOMAIN ItemAcquisitionDate AS DATE CHECK (VALUE > '1990-07-01');
	CREATE DOMAIN ItemInsuranceValue AS SMALLINT CHECK (VALUE >0);
	CREATE DOMAIN ItemDescription AS TEXT DEFAULT 'No available description for this Item.';
	CREATE DOMAIN ItemMedium AS CHAR (15) NOT NULL; 


-- Create MuseumCollection and WorksMedium Tables 
-- .. (These table are the main database of all works in the museum i.e. Assignment # 0)
	
	
-- This table records all information regarding the museum collection
-- except the works' medium (i.e. materials used)- (1:1) relation.

	CREATE TABLE MuseumCollection (  
		MC_ItemAlphaKey ItemAlphaKey,
		MC_ItemNumKey ItemNumKey,
		MC_ItemName ItemName,
		MC_Type Type,
		MC_SubType SubType,
		MC_ItemSource ItemSource,
		MC_ItemComplYear ItemComplYear,
		MC_ItemAcquisitionDate ItemAcquisitionDate,
		MC_ItemInsuranceValue ItemInsuranceValue,
		MC_ItemDescription ItemDescription,

		PRIMARY KEY(MC_ItemAlphaKey, MC_ItemNumKey)
	);


-- This table records the medium and material used for all works in the museum
-- (1:n) relation.

	CREATE TABLE WorksMedium (
		WM_ItemAlphaKey ItemAlphaKey,
		WM_ItemNumKey ItemNumKey,
		WM_ItemMedium ItemMedium,
	
		FOREIGN KEY (WM_ItemAlphaKey, WM_ItemNumKey)
			REFERENCES MuseumCollection (MC_ItemAlphaKey, MC_ItemNumKey) 
			ON UPDATE CASCADE 
			ON DELETE CASCADE
	);

-- This table records the location of all Items in the museum.
	
	CREATE TABLE ItemsLocation (
		ITL_ItemAlphaKey ItemAlphaKey,
		ITL_ItemNumKey ItemNumKey,
		ITL_ItemLocation ItemLocation,
	
		FOREIGN KEY (ITL_ItemAlphaKey, ITL_ItemNumKey)
			REFERENCES MuseumCollection (MC_ItemAlphaKey, MC_ItemNumKey) 
			ON UPDATE CASCADE 
			ON DELETE CASCADE, 

		FOREIGN KEY (ITL_ItemLocation)
			REFERENCES MuseumLocations (ML_LocationName) 
			ON UPDATE CASCADE 
			ON DELETE CASCADE
	);




-------------- ****  Exhibitions Database **** ----------

-- Domains for Exhibitions and ExhibitionsCollection Tables.

	CREATE DOMAIN ExhName AS TEXT DEFAULT '';
	CREATE DOMAIN ExhStartdate AS DATE;
	CREATE DOMAIN ExhEnddate AS DATE;
	CREATE DOMAIN ExhLocation AS CHAR (50) NOT NULL;
	CREATE DOMAIN ExhDescription AS TEXT DEFAULT 'No available description for this Exhibition.';
	


-- This table Records all the information regarding currently ongoing Exhibitions in the
-- .. museum.

	CREATE TABLE Exhibitions (
		EX_ExhName ExhName,
		EX_ExhStartdate ExhStartdate,
		EX_ExhEnddate ExhEnddate,
		EX_ExhLocation ExhLocation,
		EX_ExhDescription ExhDescription, 

		PRIMARY KEY(EX_ExhName),
		FOREIGN KEY (EX_ExhLocation)
			REFERENCES MuseumLocations (ML_LocationName) 
			ON UPDATE CASCADE 
			ON DELETE CASCADE
	);

-- This table records all museum works and items that exist in each Exhibition.
	
	CREATE TABLE ExhibitionsCollection (
		
		EXC_ItemAlphaKey ItemAlphaKey,
		EXC_ItemNumKey ItemNumKey,
		EXC_ExhName  ExhName,

		PRIMARY KEY(EXC_ItemAlphaKey, EXC_ItemNumKey, EXC_ExhName),

		FOREIGN KEY (EXC_ItemAlphaKey, EXC_ItemNumKey)
			REFERENCES MuseumCollection (MC_ItemAlphaKey, MC_ItemNumKey)
			ON UPDATE CASCADE 
			ON DELETE CASCADE,

		FOREIGN KEY (EXC_ExhName)
			REFERENCES Exhibitions (EX_ExhName) 
			ON UPDATE CASCADE 
			ON DELETE CASCADE
	);



-------------- ****  Main Views for the Museum Database  **** ----------


-- Create a View for the MuseumLocations Table
-- .. This view allows insertion, updates and deletes (Read/Write View)

	CREATE VIEW MuseumLocationsView
		AS SELECT ML_LocationName, ML_AreaSquareMeter, ML_NumOfDoors, ML_MaxNumWorks
		FROM MuseumLocations
		;



-- Create a View for the LocationsConnections Table
-- .. This view allows insertion, updates and deletes (Read/Write View)

	CREATE VIEW LocationsConnectionsView
		AS SELECT LC_LocationName, LC_ConnectedTo
		FROM LocationsConnections
		ORDER BY LC_LocationName, LC_ConnectedTo
		;


-- Create a View for the MuseumCollection Table
-- .. This view allows insertion, updates and deletes (Read/Write View)

	CREATE VIEW MuseumCollectionView
		AS SELECT mc.MC_ItemAlphaKey, mc.MC_ItemNumKey, mc.MC_ItemName, mc.MC_Type, mc.MC_SubType, 
		mc.MC_ItemSource, mc.MC_ItemComplYear, mc.MC_ItemAcquisitionDate, mc.MC_ItemInsuranceValue, 
		mc.MC_ItemDescription 
		FROM MuseumCollection mc
		;
  
 
-- Create a View for the WorksMedium Table
-- .. This view allows insertion, updates and deletes (Read/Write View)

	CREATE VIEW WorksMediumView
		AS SELECT wm.WM_ItemAlphaKey, wm.WM_ItemNumKey, wm.WM_ItemMedium
		FROM WorksMedium wm
		;



-- Create a View for the ItemsLocationView
-- .. This view allows insertion, updates and deletes (Read/Write View)
	
	CREATE VIEW ItemsLocationView
		AS SELECT ITL_ItemAlphaKey, ITL_ItemNumKey, ITL_ItemLocation
		FROM ItemsLocation
		;



-- Create a View for the Exhibitions Table
-- .. This view allows insertion, updates and deletes (Read/Write View)

	CREATE VIEW ExhibitionsView
		AS SELECT EX_ExhName, EX_ExhStartdate, EX_ExhEnddate, EX_ExhLocation, EX_ExhDescription
		FROM Exhibitions
		;



-- Create a View for the ExhibitionsCollection Table
-- .. This view allows insertion, updates and deletes (Read/Write View)

	CREATE VIEW ExhibitionsCollectionView
		AS SELECT EXC_ItemAlphaKey, EXC_ItemNumKey, EXC_ExhName
		FROM ExhibitionsCollection
		;
