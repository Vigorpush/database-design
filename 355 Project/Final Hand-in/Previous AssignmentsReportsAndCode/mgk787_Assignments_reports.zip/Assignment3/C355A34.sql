-- Name : Mohamed Kassem
-- NSID: mgk787
-- Student no.: 11129292
-- Assignment 3 (Part 4)
-- File Name: C355A34.sql

DROP TABLE IF EXISTS ItemsLoan CASCADE;
DROP VIEW IF EXISTS ItemsLoanView CASCADE;

DROP DOMAIN IF EXISTS InstituteName CASCADE;
DROP DOMAIN IF EXISTS InstituteAddress CASCADE;
DROP DOMAIN IF EXISTS InstituteEmail CASCADE;
DROP DOMAIN IF EXISTS LoanStartDate CASCADE;
DROP DOMAIN IF EXISTS LoanEndDate CASCADE;
DROP DOMAIN IF EXISTS InstitutePhoneNum CASCADE;


-- 4. outgoing loans


-- Creating a new table to keep track of the name, address, phone number, 
-- and e-mail of the institution to which a work has been loaned, along with the start and ending dates of the loan period. 

CREATE DOMAIN InstituteName AS TEXT NOT NULL;
CREATE DOMAIN InstituteAddress AS TEXT NOT NULL;
CREATE DOMAIN InstituteEmail AS TEXT NOT NULL;
CREATE DOMAIN InstitutePhoneNum AS TEXT NOT NULL;
CREATE DOMAIN LoanStartDate AS DATE CHECK (VALUE >= '2016-11-01');
CREATE DOMAIN LoanEndDate AS DATE NOT NULL;

CREATE TABLE ItemsLoan (
		IL_ItemAlphaKey ItemAlphaKey,
		IL_ItemNumKey ItemNumKey,
		IL_InstituteName InstituteName,
		IL_InstituteAddress InstituteAddress,
		IL_InstitutePhoneNum InstitutePhoneNum,
		IL_InstituteEmail InstituteEmail,
		IL_LoanStartDate LoanStartDate,
		IL_LoanEndDate LoanStartDate,
		
		PRIMARY KEY (IL_ItemAlphaKey, IL_ItemNumKey, IL_InstituteName, IL_LoanStartDate,IL_LoanEndDate),
		FOREIGN KEY (IL_ItemAlphaKey, IL_ItemNumKey)
			REFERENCES MuseumCollection (MC_ItemAlphaKey, MC_ItemNumKey) 
			ON UPDATE CASCADE 
			ON DELETE CASCADE
	);

-- Create ItemsLoanView
CREATE VIEW ItemsLoanView
	AS SELECT IL_ItemAlphaKey, IL_ItemNumKey, IL_InstituteName, IL_InstituteAddress, IL_InstitutePhoneNum, IL_InstituteEmail, IL_LoanStartDate, IL_LoanEndDate
	FROM ItemsLoan;


-- Plan the loans of 6 different works (which you will manually select from a list of works that will be available during the time period of the loan)
-- Loan periods vary in length from 2 - 8 months
-- The starting times of loans vary from some day in November 2016 to some time in April 2017
-- Loans are to be made to a variety of (at least three) different institutions (that actually might be interested in the works).
-- Two of the works to be loaned must have been exhibited in your first set of exhibitions


-- Setting the location of a work that is loaned to another institution to "on loan" or 
-- .. some similar single value that fits within your current database schema
ALTER TABLE ItemsLocation
	DROP CONSTRAINT itemslocation_itl_itemlocation_fkey;

INSERT INTO ItemsLocationView (ITL_ItemAlphaKey, ITL_ItemNumKey, ITL_ItemLocation, ITL_Startdate, ITL_Enddate)
	VALUES  -- This item is exhibited from 2016-08-28 to 2016-12-01 in 'A Glimpse from the Life of the Christ: Sacred Arts' Exhibition.
			('SCLP', '3009','ON LOAN', '2016-11-30', '2017-03-25'),
			-- This item is exhibited from 2016-08-28 to 2016-12-01 in 'A Glimpse from the Life of the Christ: Sacred Arts' Exhibition.
			('SCLP', '3010','ON LOAN', '2016-11-30', '2017-03-25'),
			-- This item has not been in any exhibition before.
			('PNTG', '1075','ON LOAN', '2016-11-01', '2017-05-05'),
			-- These three items is  exhibited from 2016-10-28 to 2016-12-28 in ' The Woven Bridges: Classical Textiles' Exhibition.
			('TXTL', '2024','ON LOAN', '2017-01-15', '2017-04-15'),
			('TXTL', '2025','ON LOAN', '2017-01-15', '2017-04-15'),
			('TXTL', '2026','ON LOAN', '2017-01-15', '2017-04-15');

-- These Items have to be updated in the ItemsLocation table to be taken out of Storage on the start of their loading period.
UPDATE ItemsLocationView
	SET ITL_Enddate='2016-11-30'
	WHERE ITL_ItemLocation='Storage' AND ITL_ItemAlphaKey='SCLP' AND ITL_ItemNumKey IN (3009, 3010) AND ITL_Enddate= (SELECT MAX (ITL_Enddate) FROM ItemsLocationView 
	                                                                                            WHERE ITL_ItemLocation='Storage' AND ITL_ItemAlphaKey='SCLP' AND ITL_ItemNumKey IN (3009, 3010)); 

UPDATE ItemsLocationView
	SET ITL_Enddate='2016-11-01'
	WHERE ITL_ItemLocation='Storage' AND ITL_ItemAlphaKey='PNTG' AND ITL_ItemNumKey IN (1075) AND ITL_Enddate= (SELECT MAX (ITL_Enddate) FROM ItemsLocationView 
	                                                                                            WHERE ITL_ItemLocation='Storage' AND ITL_ItemAlphaKey='SCLP' AND ITL_ItemNumKey IN (1075));

	UPDATE ItemsLocationView
	SET ITL_Enddate='2017-01-15'
	WHERE ITL_ItemLocation='Storage' AND ITL_ItemAlphaKey='TXTL' AND ITL_ItemNumKey IN (2024, 2025, 2026) AND ITL_Enddate= (SELECT MAX (ITL_Enddate) FROM ItemsLocationView 
	                                                                                            WHERE ITL_ItemLocation='Storage' AND ITL_ItemAlphaKey='TXTL' AND ITL_ItemNumKey IN (2024, 2025, 2026));


-- Loans are to be made to a variety of (at least three) different institutions (that actually might be interested in the works).
INSERT INTO ItemsLoanView (IL_ItemAlphaKey, IL_ItemNumKey, IL_InstituteName, IL_InstituteAddress, IL_InstitutePhoneNum, IL_InstituteEmail, IL_LoanStartDate, IL_LoanEndDate)
	SELECT ITL_ItemAlphaKey, ITL_ItemNumKey, 'Victoria and Albert Museum','Cromwell Rd, London SW7 2RL, United Kingdom','+44 (20) 7646-0400', 'museum@vam.uk' ,ITL_Startdate, ITL_Enddate
	FROM ItemsLocationView itlv
	WHERE ITL_ItemLocation='ON LOAN' AND ITL_ItemAlphaKey='SCLP' AND ITL_ItemNumKey IN (3009, 3010);


INSERT INTO ItemsLoanView (IL_ItemAlphaKey, IL_ItemNumKey, IL_InstituteName, IL_InstituteAddress, IL_InstitutePhoneNum, IL_InstituteEmail, IL_LoanStartDate, IL_LoanEndDate)
	SELECT ITL_ItemAlphaKey, ITL_ItemNumKey, 'The Metropolitan Museum of Art','1000 5th Ave, New York, NY 10028, United States','+1 (800) 468-7386', 'metmuseum@met.gov' ,ITL_Startdate, ITL_Enddate
	FROM ItemsLocationView itlv
	WHERE ITL_ItemLocation='ON LOAN' AND ITL_ItemAlphaKey='PNTG' AND ITL_ItemNumKey IN (1075);



INSERT INTO ItemsLoanView (IL_ItemAlphaKey, IL_ItemNumKey, IL_InstituteName, IL_InstituteAddress, IL_InstitutePhoneNum, IL_InstituteEmail, IL_LoanStartDate, IL_LoanEndDate)
	SELECT ITL_ItemAlphaKey, ITL_ItemNumKey, 'Textile Museum of Canada','55 Centre Ave, Toronto, ON M5G 2H5','+1 (416) 599-5321', 'must@textilemuseum.ca' ,ITL_Startdate, ITL_Enddate
	FROM ItemsLocationView itlv
	WHERE ITL_ItemLocation='ON LOAN' AND ITL_ItemAlphaKey='TXTL' AND ITL_ItemNumKey IN (2024, 2025, 2026);



