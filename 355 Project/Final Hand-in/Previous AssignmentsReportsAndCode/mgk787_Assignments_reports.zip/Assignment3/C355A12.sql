-- Name : Mohamed Kassem
-- NSID: mgk787
-- Student no.: 11129292
-- Assignment 1 (Part 2)
-- File Name: C355A12.sql



-- copy data to the main data base tables 
-- .. These are the tables from Assingmnet 0

\copy museumcollection FROM 'C355A12-1.txt'

\copy WorksMedium  FROM 'C355A12-2.txt'



-- The following is a schematic diagram of my museum structure:-

--           50m        50m
--      o----------o-----------o
--      |          /   Lobby   / 20m --> EXIT
--      |          |           |
--      |          o--/-----/--0
--      |          |     |     |
--      |          |  A  |  B  |
-- 150m |  Storage |     /     | 65m
--      |          |     |     |
--      |          |     |     |
--      |          |--/--o--/--o
--      |          | 25m   25m |
--      |          |           |
--      |          |     C     | 65m
--      |          |           |
--      |          |           |
--      o----------o-----------o 

-- Add data on the the locations (including three galleries, lobby, storage and connecting doors).
-- ML_MaxNumWorks is the maximum number of items the location can have and it's different
-- .. from the suggested minimum and maximum number of items given in the assignment specification.

INSERT INTO MuseumLocationsView (ML_LocationName, ML_AreaSquareMeter, ML_NumOfDoors, ML_MaxNumWorks)
	VALUES ('Storage', 7500, 1, 1000),
	       ('Lobby', 1000, 4, 6),
	       ('Gallery_A', 1625, 3, 20),
	       ('Gallery_B',1625, 3, 20),
	       ('Gallery_C', 3250, 2, 45);


INSERT INTO LocationsConnectionsView (LC_LocationName, LC_ConnectedTo)
	VALUES ('Storage', 'Lobby'),
	       ('Lobby', 'Storage'),
	       ('Lobby', 'Gallery_A'),
	       ('Lobby', 'Gallery_B'),
	       ('Gallery_A', 'Lobby'),
	       ('Gallery_A','Gallery_B'),
	       ('Gallery_A', 'Gallery_C'),
	       ('Gallery_B', 'Lobby'),
	       ('Gallery_B','Gallery_A'),
	       ('Gallery_B', 'Gallery_C'),
	       ('Gallery_C', 'Gallery_A'),
	       ('Gallery_C','Gallery_B');



-- Place all items initially in your museum's storage facility.

INSERT INTO ItemsLocationView (ITL_ItemAlphaKey, ITL_ItemNumKey, ITL_ItemLocation)
	SELECT mc.MC_ItemAlphaKey, mc.MC_ItemNumKey, 'Storage'
	FROM MuseumCollection mc;


-- Create three exhibitions that are currently taking place
-- One exhibition should have started during July 2016, one during August 2016, and one during September 2016.
-- Exhibition 1: A Glimpse from the Life of the Christ: Sacred Arts from 2016-07-15 to 2016-10-25.
-- Exhibition 2: Still life in European Art from 2016-08-20 to 2016-11-20.
-- Exhibition 3:The Woven Bridges from 2016-09-25 to 2016-12-20.

INSERT INTO ExhibitionsView (EX_ExhName, EX_ExhStartdate, EX_ExhEnddate, EX_ExhLocation, EX_ExhDescription)
	VALUES ('A Glimpse from the Life of the Christ: Sacred Arts', '2016-08-28', '2016-12-01', 'Gallery_B', 'The exhibition presents some fascinating and beautiful art works that depict the life of the Christ and Virgin Mary through different stages of their life. In addition, the exhibition presents other artworks from the Christian History'),
	       ('Still life in European Art', '2016-07-20', '2016-11-25', 'Gallery_A', 'The exhibition presents a group of still life works painted by different European artists between the 17th and 18th century. These Oil painted works shows the continuous development of the still life in European art.'),
	       ('The Woven Bridges: Classical Textiles', '2016-09-25', '2016-12-28','Gallery_C', 'The exhibition presents a group of perfectly woven tapestries and carpets from different Middle Eastern and European countries. These group of textile works reflect the different in woven styling, materials and design between the East and West textile Art');


-- Place the selected items in these exhibitions
-- One exhibition should contain 9 works, one 10 works, and one 16 works.

-- Placing Items in Exhibition 1: A Glimpse from the Life of the Christ: Sacred Arts (9 Items inserted).

INSERT INTO ExhibitionsCollectionView(EXC_ExhName, EXC_ItemAlphaKey, EXC_ItemNumKey)
	SELECT 'A Glimpse from the Life of the Christ: Sacred Arts', MC_ItemAlphaKey, MC_ItemNumKey 
	FROM MuseumCollection
	WHERE (MC_ItemAlphaKey='PNTG' AND MC_ItemNumKey IN (1002, 1008, 1014, 1018, 1022, 1024)) OR
		  (MC_ItemAlphaKey='TXTL' AND MC_ItemNumKey=2001) OR
		  (MC_ItemAlphaKey='SCLP' AND MC_ItemNumKey IN (3012, 3013));

-- Placing Items in Exhibition 2: Still life in European Art (10 Items inserted).

INSERT INTO ExhibitionsCollectionView(EXC_ExhName, EXC_ItemAlphaKey, EXC_ItemNumKey)
	SELECT 'Still life in European Art', MC_ItemAlphaKey, MC_ItemNumKey 
	FROM MuseumCollection
	WHERE (MC_ItemAlphaKey='PNTG' AND MC_ItemNumKey IN (1007, 1020, 1021, 1025, 1026, 1027, 1028, 1029, 1030, 1031));



-- Placing Items in Exhibition 3: The Woven Bridges: Classical Textiles (16 Items inserted).

INSERT INTO ExhibitionsCollectionView(EXC_ExhName, EXC_ItemAlphaKey, EXC_ItemNumKey)
	SELECT 'The Woven Bridges: Classical Textiles', MC_ItemAlphaKey, MC_ItemNumKey 
	FROM MuseumCollection
	WHERE (MC_ItemAlphaKey='TXTL' AND MC_ItemNumKey IN (2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2012, 2013, 2014, 2015, 2016, 2017, 2018));

	
-- Assign two special works to be displayed in the lobby.
-- .. The two special items added are PNTG 1001 and PNTG 1005
UPDATE ItemsLocationView 
SET ITL_ItemLocation='Lobby'
WHERE ITL_ItemAlphaKey='PNTG' AND ITL_ItemNumKey IN (1001, 1005);



-- Update the location of all works that are now in exhibitions
-- Note: You can query this Item to check that it's correct, but it is.
UPDATE ItemsLocationView AS Itv
SET ITL_ItemAlphaKey=foo.EXC_ItemAlphaKey, 
    ITL_ItemNumKey=foo.EXC_ItemNumKey, 
    ITL_ItemLocation=foo.EX_ExhLocation 
	FROM ( SELECT EXC_ItemAlphaKey, EXC_ItemNumKey, EX_ExhLocation
				FROM ExhibitionsCollectionView exw, ExhibitionsView ex
				WHERE exw.EXC_ExhName = ex.EX_ExhName) AS foo (EXC_ItemAlphaKey, EXC_ItemNumKey, EX_ExhLocation)
		WHERE Itv.ITL_ItemAlphaKey=foo.EXC_ItemAlphaKey AND Itv.ITL_ItemNumKey=foo.EXC_ItemNumKey
;






