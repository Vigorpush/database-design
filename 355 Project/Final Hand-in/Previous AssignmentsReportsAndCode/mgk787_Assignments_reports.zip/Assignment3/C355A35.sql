-- Name : Mohamed Kassem
-- NSID: mgk787
-- Student no.: 11129292
-- Assignment 3 (Part 5)
-- File Name: C355A35.sql



DROP DOMAIN IF EXISTS SponsorName CASCADE;
DROP DOMAIN IF EXISTS ExhCityAddress CASCADE;
DROP DOMAIN IF EXISTS SecurityName CASCADE;
DROP DOMAIN IF EXISTS ExhInsuranceValue CASCADE;

DROP TABLE IF EXISTS TravelingExhibitions CASCADE;
DROP VIEW IF EXISTS TravelingExhibitionsView CASCADE;

-- 5. Traveling exhibitions
CREATE DOMAIN SponsorName AS CHAR (50);
CREATE DOMAIN ExhCityAddress AS TEXT NOT NULL;
CREATE DOMAIN SecurityName AS CHAR (50);
CREATE DOMAIN ExhInsuranceValue AS INT NOT NULL;

-- Create a Travelling Exhibition table: this table records  the following data on each temporary location: name of sponsor of traveling exhibition, address of the temporary location, 
-- .. name of individual in charge of security, amount of insurance provided for exhibition 
-- .  (which must be at least 10% higher than the total value of current insurance value of the individual works in the exhibition)
CREATE TABLE TravelingExhibitions ( 
		TE_ExhName ExhName,
		TE_SponsorName SponsorName,
		TE_ExhAddress_City ExhCityAddress,
		TE_SecurityName SecurityName,
		TE_ExhInsuranceValue ExhInsuranceValue,
		
		PRIMARY KEY (TE_ExhName, TE_SponsorName, TE_ExhAddress_City),
		FOREIGN KEY (TE_ExhName)
			REFERENCES Exhibitions (EX_ExhName) 
			ON UPDATE CASCADE 
			ON DELETE CASCADE
	);
-- Create TravelingExhibitionsView
CREATE VIEW TravelingExhibitionsView
	AS SELECT TE_ExhName, TE_SponsorName, TE_ExhAddress_City, TE_SecurityName, TE_ExhInsuranceValue
	FROM TravelingExhibitions;


-- You should plan this exhibition based on (your manulally selecting from the results of an appropriate query) 
-- .. the earliest ending exhibition from Assignment #1
-- this traveling exhibition should travel to five Saskatchewan towns or cities that will each have the exhibition available to the public for three weeks. 


--SELECT * FROM ExhibitionsLocationView; 
-- This query will show all current and planned exhibitions with their starting and Ending date.
-- Based on the previous query, the earliest ending exhibition from Assignment #1 is:  Still life in European Art
-- .. from 2016-07-20 to 2016-11-25.

INSERT INTO TravelingExhibitionsView (TE_ExhName, TE_SponsorName, TE_ExhAddress_City, TE_SecurityName, TE_ExhInsuranceValue)
	VALUES  
			('Still life in European Art', 'Cameco Corporation', 'Saskatoon, SK', 'James Bonfield', '0' ),
			('Still life in European Art', 'City Of Regina','Regina, SK', 'James Bonfield', '0'),
			('Still life in European Art', 'Saskatchewan Ministry Of Tourism','Moose Jaw, SK', 'James Bonfield', '0'),			
			('Still life in European Art', 'Goverment Of Saskatchewan','Prince Albert, SK', 'James Bonfield', '0'),
			('Still life in European Art', 'SaskTel', 'Rosetown, SK','James Bonfield', '0');
			
-- Update Insurance value of the travelling Exhibition.
UPDATE TravelingExhibitionsView
SET TE_ExhInsuranceValue= 1.1* (SELECT SUM(MC_ItemInsuranceValue) FROM MuseumCollectionView mcv, ExhibitionsCollectionView excv
									WHERE mcv.MC_ItemAlphaKey=excv.EXC_ItemAlphaKey AND mcv.MC_ItemNumKey=excv.EXC_ItemNumKey AND excv.EXC_ExhName='Still life in European Art')

WHERE TE_ExhName='Still life in European Art';


									
-- Insert this travelling Exhibition in to ExhibitionLocationView (i.e. Exhibition)
INSERT INTO ExhibitionsLocationView (EXL_ExhName, EXL_ExhLocation, EXL_ExhStartdate, EXL_ExhEnddate)
SELECT TE_ExhName, TE_ExhAddress_City, '2016-11-26', '2016-12-16'
FROM TravelingExhibitionsView texv
WHERE texv.TE_ExhName='Still life in European Art' AND texv.TE_ExhAddress_City='Saskatoon, SK';


INSERT INTO ExhibitionsLocationView (EXL_ExhName, EXL_ExhLocation, EXL_ExhStartdate, EXL_ExhEnddate)
SELECT TE_ExhName, TE_ExhAddress_City, '2016-12-17', '2017-01-06'
FROM TravelingExhibitionsView texv
WHERE texv.TE_ExhName='Still life in European Art' AND texv.TE_ExhAddress_City='Regina, SK';

INSERT INTO ExhibitionsLocationView (EXL_ExhName, EXL_ExhLocation, EXL_ExhStartdate, EXL_ExhEnddate)
SELECT TE_ExhName, TE_ExhAddress_City, '2017-01-07', '2017-01-27'
FROM TravelingExhibitionsView texv
WHERE texv.TE_ExhName='Still life in European Art' AND texv.TE_ExhAddress_City='Moose Jaw, SK';

INSERT INTO ExhibitionsLocationView (EXL_ExhName, EXL_ExhLocation, EXL_ExhStartdate, EXL_ExhEnddate)
SELECT TE_ExhName, TE_ExhAddress_City, '2017-01-28', '2017-02-17'
FROM TravelingExhibitionsView texv
WHERE texv.TE_ExhName='Still life in European Art' AND texv.TE_ExhAddress_City='Prince Albert, SK';

INSERT INTO ExhibitionsLocationView (EXL_ExhName, EXL_ExhLocation, EXL_ExhStartdate, EXL_ExhEnddate)
SELECT TE_ExhName, TE_ExhAddress_City, '2017-02-18', '2017-03-10'
FROM TravelingExhibitionsView texv
WHERE texv.TE_ExhName='Still life in European Art' AND texv.TE_ExhAddress_City='Rosetown, SK';


-- Lastly, we need to update the Locations of the travelling exhibition items in the ItemsLocationView (i.e. ItemsLocation table) to reflect these moves
-- Items in the "Still life in European Art" Exhibition need to be taken out of Storage after the end of the exhibition and get ready for travellings
UPDATE ItemsLocationView
	SET ITL_Enddate='2016-11-26'
	WHERE ITL_ItemLocation='Storage' AND ITL_ItemAlphaKey='PNTG' AND ITL_ItemNumKey IN (1007, 1020, 1021, 1025, 1026, 1027, 1028, 1029, 1030, 1031,1054, 1055, 1056, 1057, 1058, 1059) AND ITL_Enddate= (SELECT MAX (ITL_Enddate) FROM ItemsLocationView 
	                                                                                            WHERE ITL_ItemLocation='Storage' AND ITL_ItemAlphaKey='PNTG' AND ITL_ItemNumKey IN (1007, 1020, 1021, 1025, 1026, 1027, 1028, 1029, 1030, 1031,1054, 1055, 1056, 1057, 1058, 1059)); 

INSERT INTO ItemsLocationView (ITL_ItemAlphaKey, ITL_ItemNumKey, ITL_ItemLocation, ITL_Startdate, ITL_Enddate)
	SELECT EXC_ItemAlphaKey, EXC_ItemNumKey, 'ON TRAVEL- Saskatoon, SK', '2016-11-26', '2016-12-16'
	FROM ExhibitionsCollectionView excv 
	WHERE EXC_ExhName='Still life in European Art';

INSERT INTO ItemsLocationView (ITL_ItemAlphaKey, ITL_ItemNumKey, ITL_ItemLocation, ITL_Startdate, ITL_Enddate)
	SELECT EXC_ItemAlphaKey, EXC_ItemNumKey, 'ON TRAVEL- Regina, SK', '2016-12-17', '2017-01-06'
	FROM ExhibitionsCollectionView excv 
	WHERE EXC_ExhName='Still life in European Art';

INSERT INTO ItemsLocationView (ITL_ItemAlphaKey, ITL_ItemNumKey, ITL_ItemLocation, ITL_Startdate, ITL_Enddate)
	SELECT EXC_ItemAlphaKey, EXC_ItemNumKey, 'ON TRAVEL- Moose Jaw, SK', '2017-01-07', '2017-01-27'
	FROM ExhibitionsCollectionView excv 
	WHERE EXC_ExhName='Still life in European Art';


INSERT INTO ItemsLocationView (ITL_ItemAlphaKey, ITL_ItemNumKey, ITL_ItemLocation, ITL_Startdate, ITL_Enddate)
	SELECT EXC_ItemAlphaKey, EXC_ItemNumKey, 'ON TRAVEL- Prince Albert, SK','2017-01-28', '2017-02-17'
	FROM ExhibitionsCollectionView excv 
	WHERE EXC_ExhName='Still life in European Art';


INSERT INTO ItemsLocationView (ITL_ItemAlphaKey, ITL_ItemNumKey, ITL_ItemLocation, ITL_Startdate, ITL_Enddate)
	SELECT EXC_ItemAlphaKey, EXC_ItemNumKey, 'ON TRAVEL- Rosetown, SK','2017-02-18', '2017-03-10'
	FROM ExhibitionsCollectionView excv 
	WHERE EXC_ExhName='Still life in European Art';
