-- Name : Mohamed Kassem
-- NSID: mgk787
-- Student no.: 11129292
-- Assignment 3 (Part 1)
-- File Name: C355A31.sql

DROP DOMAIN IF EXISTS ReturnDate CASCADE;
DROP DOMAIN IF EXISTS itemStartdateTime CASCADE;
DROP DOMAIN IF EXISTS itemEnddateTime CASCADE;
DROP DOMAIN IF EXISTS InstituteName CASCADE;
DROP DOMAIN IF EXISTS InstituteAddress CASCADE;
DROP DOMAIN IF EXISTS InstituteEmail CASCADE;
DROP DOMAIN IF EXISTS LoanStartDate CASCADE;
DROP DOMAIN IF EXISTS LoanEndDate CASCADE;
DROP DOMAIN IF EXISTS InstitutePhoneNum CASCADE;
DROP DOMAIN IF EXISTS SponsorName CASCADE;
DROP DOMAIN IF EXISTS ExhCityAddress CASCADE;
DROP DOMAIN IF EXISTS SecurityName CASCADE;
DROP DOMAIN IF EXISTS ExhInsuranceValue CASCADE;



DROP TABLE IF EXISTS ItemsLoan CASCADE;
DROP TABLE IF EXISTS TravelingExhibitions CASCADE;

DROP VIEW IF EXISTS ItemsLoanView CASCADE;
DROP VIEW IF EXISTS TravelingExhibitionsView CASCADE;


-- There are two associate files to this file: C355A31-1.txt and C355A31-2.txt

\pset pager off
\pset format wrapped
\pset border 0

\i 'Assignment2.sql'


--Few changes on Assignment 2 database (Check report for more details)

-- Added two more columns EXL_ExhStartdate and EXL_ExhEnddate to ExhibitionsLocation table.
ALTER TABLE ExhibitionsLocation ADD COLUMN EXL_ExhStartdate ExhStartdate;
ALTER TABLE ExhibitionsLocation ADD COLUMN EXL_ExhEnddate ExhEnddate;

ALTER TABLE ExhibitionsLocation ADD PRIMARY KEY(EXL_ExhName, EXL_ExhLocation, EXL_ExhStartdate, EXL_ExhEnddate);

-- Recreating the ExhibitionsLocationView
CREATE OR REPLACE VIEW ExhibitionsLocationView
	AS SELECT EXL_ExhName, EXL_ExhLocation, EXL_ExhStartdate, EXL_ExhEnddate
	FROM ExhibitionsLocation
	ORDER BY EXL_ExhStartdate
	;

-- Copy data about the Starting and Ending date of Exhibition from the ExhibitionView (i.e. Exhibition table) 
UPDATE ExhibitionsLocationView
SET EXL_ExhStartdate = (SELECT EX_ExhStartdate
                       FROM ExhibitionsView WHERE EXL_ExhName=EX_ExhName);

UPDATE ExhibitionsLocationView
SET EXL_ExhEnddate = (SELECT EX_ExhEnddate
                       FROM ExhibitionsView WHERE EXL_ExhName=EX_ExhName);


-- Drop EX_ExhStartdate and EX_ExhEnddate from Exhibitions table to avoid redundancy

ALTER TABLE Exhibitions
	DROP COLUMN EX_ExhStartdate CASCADE;
ALTER TABLE Exhibitions
	DROP COLUMN EX_ExhEnddate CASCADE;

CREATE OR REPLACE VIEW  ExhibitionsView
	AS SELECT EX_ExhName, EX_ExhDescription
	FROM Exhibitions
	;

-- Altering the Exhibitions table by dropping attributes will result in dropping four other views from Assignment 1. 
-- Below is a list of all dropped views due to these changes:

--	Exhibitionslistpublicview (Recreated in sql-code copied from assignment 1, part 3)
--	Exhibitionsadditionalworksview (Recreated in sql-code copied from assignment 1, part 3)
--	Locationsavailabilityview (Recreated in sql-code copied from assignment 2, part 1)
--	itemsavailiabiltynewexhibitions (This View will be recreated later in this part, as there will be some other following changes that will drop it again.)

-- ExhibitionsListPublicView: Produce for the public a listing of all exhibitions (including name, description, location, and number of works)
CREATE OR REPLACE VIEW  ExhibitionsListPublicView
AS SELECT EXL_ExhName, EXL_ExhLocation, (SELECT COUNT(*)
													FROM ExhibitionsCollectionView
													WHERE EXC_ExhName = EXL_ExhName)
													AS EX_NumOfWorks, EX_ExhDescription
FROM ExhibitionsLocation exlv, Exhibitions exv
WHERE exlv.EXL_ExhName=exv.EX_ExhName;


-- ExhibitionsAdditionalWorksView: Produce for the curator a listing of the amount of additional works that could be added to each 
-- exhibit based on the unused capacity of the galleries that they are currently in.
 
CREATE OR REPLACE VIEW ExhibitionsAdditionalWorksView
	AS SELECT elpv.EXL_ExhName, (mlv.ML_MaxNumWorks-elpv.EX_NumOfWorks) AS NumOfAdditionalWork
	FROM  MuseumLocationsView mlv, ExhibitionsListPublicView  elpv
	WHERE elpv.EXL_ExhLocation=mlv.ML_LocationName
	;

-- LocationsAvailabilityView: Produce for a curator a listing of works sorted by when they are available for use in a new exhibition and by classification and by name of the work
-- Note: Items which will be available immediately for current use (i.e. not in any running exhibitions), will be listed with an available date = 2016-10-05
-- ..(i.e. the assignment deadline)
CREATE OR REPLACE VIEW LocationsAvailabilityView
AS SELECT exlv.EXL_ExhLocation, mlv.ML_MaxNumWorks, exlv.EXL_ExhStartdate, exlv.EXL_ExhEnddate
	FROM MuseumLocationsView mlv, ExhibitionsLocationView exlv
	WHERE exlv.EXL_ExhLocation=mlv.ML_LocationName
	ORDER BY EXL_ExhLocation;
;

-- Dropping Trigger trigger_newExhibitionInserted
DROP TRIGGER IF EXISTS trigger_newExhibitionInserted ON Exhibitions;


-- Recreating trigger_ItemInsertedInExhibition() function. This function is executed 
-- AFTER any INSERT in to ExhibitionsCollection table OR view. (Read report for more details)
CREATE OR REPLACE FUNCTION trigger_ItemInsertedInExhibition() RETURNS TRIGGER AS
$BODY$
    BEGIN
        
		-- IF the newly INSERTED item in ExhibitionsCollectionView already exists in any of the rows of the ItemsLocationView, then firstly
		-- update the End date of this item to be the same as starting date of the Exhibition in which this same item is place in. 
		IF NEW.EXC_ExhName IN ('Test Exhibition 1', 'Test Exhibition 2', 'Test Exhibition 3') THEN

			UPDATE ItemsLocationView
			SET ITL_Enddate=foo.EXL_ExhStartdate
			FROM ( SELECT	NEW.EXC_ItemAlphaKey,
       					NEW.EXC_ItemNumKey,
      					exlv.EXL_ExhLocation,
       					exlv.EXL_ExhStartdate,
      					exlv.EXL_ExhEnddate
    				FROM exhibitionslocationView exlv
    				WHERE exlv.EXL_ExhName = NEW.EXC_ExhName) AS foo (EXC_ItemAlphaKey, EXC_ItemNumKey, EXL_ExhLocation, EXL_ExhStartdate, EXL_ExhEnddate)
			WHERE ITL_ItemAlphaKey=foo.EXC_ItemAlphaKey AND ITL_ItemNumKey=foo.EXC_ItemNumKey AND ITL_ItemAlphaKey=NEW.EXC_ItemAlphaKey AND ITL_ItemNumKey=NEW.EXC_ItemNumKey AND ITL_ItemLocation='Storage' AND ITL_Enddate= (SELECT MIN (ITL_Enddate) FROM ItemsLocationView
																																																							WHERE ITL_ItemAlphaKey= NEW.EXC_ItemAlphaKey AND ITL_ItemNumKey= NEW.EXC_ItemNumKey AND ITL_ItemLocation='Storage');
				
		ELSE

			UPDATE ItemsLocationView
			SET ITL_Enddate=foo.EXL_ExhStartdate
			FROM ( SELECT	NEW.EXC_ItemAlphaKey,
       					NEW.EXC_ItemNumKey,
      					exlv.EXL_ExhLocation,
       					exlv.EXL_ExhStartdate,
      					exlv.EXL_ExhEnddate
    				FROM exhibitionslocationView exlv
    				WHERE exlv.EXL_ExhName = NEW.EXC_ExhName) AS foo (EXC_ItemAlphaKey, EXC_ItemNumKey, EXL_ExhLocation, EXL_ExhStartdate, EXL_ExhEnddate)
			WHERE ITL_ItemAlphaKey=foo.EXC_ItemAlphaKey AND ITL_ItemNumKey=foo.EXC_ItemNumKey AND ITL_ItemAlphaKey=NEW.EXC_ItemAlphaKey AND ITL_ItemNumKey=NEW.EXC_ItemNumKey AND ITL_ItemLocation='Storage' AND ITL_Enddate= (SELECT MAX (ITL_Enddate) FROM ItemsLocationView
																																																							WHERE ITL_ItemAlphaKey= NEW.EXC_ItemAlphaKey AND ITL_ItemNumKey= NEW.EXC_ItemNumKey AND ITL_ItemLocation='Storage');
				
		END IF;

		-- INSERT the newly added item in to the ItemsLocationView with a starting date and ending dates equal to that of the Exhibition,
		-- in which the item is place in.
		INSERT INTO ItemsLocationView (ITL_ItemAlphaKey, ITL_ItemNumKey, ITL_ItemLocation, ITL_Startdate, ITL_Enddate)
      		SELECT  NEW.EXC_ItemAlphaKey,
       				NEW.EXC_ItemNumKey,
      				exlv.EXL_ExhLocation,
       				exlv.EXL_ExhStartdate,
      				exlv.EXL_ExhEnddate
    		FROM exhibitionslocationView exlv
    		WHERE exlv.EXL_ExhName = NEW.EXC_ExhName;
   
		RETURN NULL;
    END;
$BODY$
	LANGUAGE plpgsql;


-- Adding two new columns (i.e. attributes) ITO_Acquisition_Borrowing_Date and ITO_Returning_SellingDate to ItemsOwnership table.

-- First, create a new domain for the new attributes
CREATE DOMAIN ReturnDate AS DATE CHECK (VALUE > '1990-07-01');;
ALTER TABLE ItemsOwnership
  ADD ITO_Acquisition_Borrowing_Date ItemAcquisitionDate; -- ItemAcquisitionDate is a previously defined domain from Assignment 1.
ALTER TABLE ItemsOwnership
  ADD ITO_Returning_SellingDate ReturnDate DEFAULT NULL;

-- Recreate ItemsOwnershipView (Read comments in my report).
CREATE OR REPLACE VIEW ItemsOwnershipView
	AS SELECT ITO_ItemAlphaKey, ITO_ItemNumKey, ITO_Ownership_Status, ITO_BorrowedFrom, ITO_Acquisition_Borrowing_Date, ITO_Returning_SellingDate
		FROM ItemsOwnership
		;
-- Copy all items currently in our database collection (i.e. MuseumCollection Table) in to ItemsOwnershipView with an Ownership_Status='OWNED-PURCHASE', 
-- ITO_BorrowedFrom ='NONE', ITO_Acquisition_Borrowing_Date equal to their actual acquisition date and ITO_Returning_SellingDate= NULL (No returning date for an owned or purchased items)
INSERT INTO ItemsOwnershipView (ITO_ItemAlphaKey, ITO_ItemNumKey, ITO_Ownership_Status, ITO_BorrowedFrom, ITO_Acquisition_Borrowing_Date, ITO_Returning_SellingDate)
	SELECT MC_ItemAlphaKey, MC_ItemNumKey, 'OWNED-PURCHASED', 'NONE', MC_ItemAcquisitionDate, NULL
	FROM MuseumCollectionView;
	

-- Missing from Assignment 2.
-- Add 15 new works to my database collection (i.e. MuseumCollection Table) and have them be long term borrowed works (From Assignment 2 requirement)

\copy MuseumCollection FROM 'C355A31-1.txt' -- This line will add 15 new items to our database collection (i.e. MuseumCollection Table)
\copy WorksMedium FROM 'C355A31-2.txt' -- This line will add data regarding work medium/media for the 15 newly added items.

-- Now, we have to add these 15 new items to ItemsOwnershipView (i.e. ItemsOwnership table) with Ownership_Status='LONG TERM BORROWED',
-- ITO_BorrowedFrom = some cartoon characters donors, and ITO_Acquisition_Borrowing_Date equal to their actual acquisition date and ITO_Returning_SellingDate= to some time in the far future.

-- Seven out of the 15 new items are borrowed from Sir. Sir. Henry Clay Frick
INSERT INTO ItemsOwnershipView (ITO_ItemAlphaKey, ITO_ItemNumKey, ITO_Ownership_Status, ITO_BorrowedFrom, ITO_Acquisition_Borrowing_Date, ITO_Returning_SellingDate)
	SELECT MC_ItemAlphaKey, MC_ItemNumKey, 'LONG TERM BORROWED', 'Sir. Henry Clay Frick', MC_ItemAcquisitionDate, '2030-12-31'
	FROM MuseumCollectionView
	WHERE (MC_ItemAlphaKey='CLCK' AND MC_ItemNumKey IN (4010, 4011, 4012, 4013, 4014, 4014, 4015, 4016));

-- Another Five out of the 15 new items are borrowed from Madame. Marie Laforêt
INSERT INTO ItemsOwnershipView (ITO_ItemAlphaKey, ITO_ItemNumKey, ITO_Ownership_Status, ITO_BorrowedFrom, ITO_Acquisition_Borrowing_Date, ITO_Returning_SellingDate)
	SELECT MC_ItemAlphaKey, MC_ItemNumKey, 'LONG TERM BORROWED', 'Madame. Marie Laforêt', MC_ItemAcquisitionDate, '2035-12-31'
	FROM MuseumCollectionView
	WHERE (MC_ItemAlphaKey='PNTG' AND MC_ItemNumKey IN (1054, 1055, 1056, 1057, 1058));

-- Another three out of the 15 new items are borrowed from Victoria Benossri
INSERT INTO ItemsOwnershipView (ITO_ItemAlphaKey, ITO_ItemNumKey, ITO_Ownership_Status, ITO_BorrowedFrom, ITO_Acquisition_Borrowing_Date, ITO_Returning_SellingDate)
	SELECT MC_ItemAlphaKey, MC_ItemNumKey, 'LONG TERM BORROWED', 'Victoria Benossri', MC_ItemAcquisitionDate, '2025-12-31'
	FROM MuseumCollectionView
	WHERE (MC_ItemAlphaKey='PNTG' AND MC_ItemNumKey IN (1059, 1060, 1061));



-- As per Assignment 1 specification, all items in the museum are initially stored  in the Storage location.
-- Since, we just added these 15 new borrowed items to our collection, we need to place them in to Storage.
-- Note the Startdate is the same as the ItemAcquisitionDate and Enddate is 2099-12-31 (Read report for more details).
INSERT INTO ItemsLocationView (ITL_ItemAlphaKey, ITL_ItemNumKey, ITL_ItemLocation, ITL_Startdate, ITL_Enddate)
	SELECT ITO_ItemAlphaKey, ITO_ItemNumKey, 'Storage', ITO_Acquisition_Borrowing_Date, ITO_Returning_SellingDate
	FROM ItemsOwnershipView
	WHERE ITO_Ownership_Status='LONG TERM BORROWED';

-- Missing from Assignment 2.
-- Add 15 new works belonging to other museums as potential works that could be borrowed (that might be used for an upcoming (not yet scheduled) special exhibition) 
-- and add data about them (as if you are able to borrow them) in your database. NOTE: these works will not actually arrive at the museum until sometime near to 
-- the start of the special exhibition for which they will be used and will be returned soon after the exhibition is finished.

\copy museumcollection FROM 'C355A31-3.txt' -- This line will add another 15 new items to our database collection (i.e. MuseumCollection Table)
\copy WorksMedium FROM 'C355A31-4.txt' -- This line will add data regarding work medium/media for the 15 newly added items.

-- Now, we have to add these other 15 new items to ItemsOwnershipView (i.e. ItemsOwnership table) with Ownership_Status='POTENTIAL BORROWING',
-- ITO_BorrowedFrom = some museums, and ITO_Acquisition_Borrowing_Date and RetuningDate= NULL 
-- (Which means that their borrowing and returning date are undetermined and need to be updated later.

-- These eight items are to be potentially borrowed from Victoria and Albert Museum
INSERT INTO ItemsOwnershipView (ITO_ItemAlphaKey, ITO_ItemNumKey, ITO_Ownership_Status, ITO_BorrowedFrom, ITO_Acquisition_Borrowing_Date, ITO_Returning_SellingDate)
	SELECT MC_ItemAlphaKey, MC_ItemNumKey, 'POTENTIAL BORROWING', 'Victoria and Albert Museum', NULL, NULL
	FROM MuseumCollectionView
	WHERE (MC_ItemAlphaKey='SCLP' AND MC_ItemNumKey IN (3001, 3002, 3003, 3004, 3005, 3006, 3007, 3008, 3011));

-- These seven items are to be potentially borrowed from National Ornamental Metal Museum
INSERT INTO ItemsOwnershipView (ITO_ItemAlphaKey, ITO_ItemNumKey, ITO_Ownership_Status, ITO_BorrowedFrom, ITO_Acquisition_Borrowing_Date, ITO_Returning_SellingDate)
	SELECT MC_ItemAlphaKey, MC_ItemNumKey, 'POTENTIAL BORROWING', 'National Ornamental Metal Museum', NULL, NULL
	FROM MuseumCollectionView
	WHERE (MC_ItemAlphaKey='MWJW' AND MC_ItemNumKey IN (5001, 5002, 5003, 5004, 5005, 5006));

--
ALTER TABLE MuseumCollection
	DROP MC_ItemAcquisitionDate CASCADE;

-- Dropping MC_ItemAcquisitionDate from MuseumCollection table, will cascade drop few views. 
-- Below is a list of views that are dropped and which will be recreated
--	   MuseumCollectionview
--	   ItemsInStoragePrivateView  
--	   ExhibitionsCollectionInfoPublicView 
--	   ItemsAvailiabiltyNewExhibitions


-- Recreating the MuseumCollectionView
CREATE OR REPLACE VIEW MuseumCollectionView
	AS SELECT mc.MC_ItemAlphaKey, mc.MC_ItemNumKey, mc.MC_ItemName, mc.MC_Type, mc.MC_SubType, 
		mc.MC_ItemSource, mc.MC_ItemComplYear, mc.MC_ItemInsuranceValue, 
		mc.MC_ItemDescription 
		FROM MuseumCollection mc
		;

-- Recreating the ExhibitionsCollectionInfoPublicView
CREATE OR REPLACE VIEW  ExhibitionsCollectionInfoPublicView
	AS SELECT ecxv.EXC_ExhName, mcv.MC_ItemAlphaKey, mcv.MC_ItemNumKey, mcv.MC_ItemName, mcv.MC_Type, mcv.MC_SubType, 
		mcv.MC_ItemSource, mcv.MC_ItemComplYear, itov.ITO_Acquisition_Borrowing_Date, mcv.MC_ItemInsuranceValue, 
		mcv.MC_ItemDescription 
	FROM MuseumCollectionView mcv, ExhibitionsCollectionView ecxv, ItemsOwnershipView itov
	WHERE mcv.MC_ItemAlphaKey = ecxv.EXC_ItemAlphaKey AND mcv.MC_ItemNumKey = ecxv.EXC_ItemNumKey AND mcv.MC_ItemAlphaKey=itov.ITO_ItemAlphaKey AND mcv.MC_ItemNumKey=itov.ITO_ItemNumKey
	ORDER BY ecxv.EXC_ExhName, mcv.MC_ItemName;

-- Recreating the ItemsInStoragePrivateView
CREATE OR REPLACE VIEW  ItemsInStoragePrivateView
AS SELECT mcv.MC_ItemAlphaKey, mcv.MC_ItemNumKey, mcv.MC_ItemName, mcv.MC_ItemInsuranceValue, 
		  Itv.ITL_ItemLocation
		FROM MuseumCollectionView mcv, ItemsLocationView Itv
		WHERE mcv.MC_ItemAlphaKey=Itv.ITL_ItemAlphaKey AND mcv.MC_ItemNumKey=Itv.ITL_ItemNumKey AND
			  Itv.ITL_ItemLocation='Storage';
		;
-- Recreating the ItemsAvailiabiltyNewExhibitions
CREATE OR REPLACE VIEW ItemsAvailiabiltyNewExhibitions
	AS 
		(SELECT mcv.MC_ItemAlphaKey, mcv.MC_ItemNumKey, mcv.MC_ItemName, mcv.MC_Type, mcv.MC_SubType, CAST (now() AS DATE) AS IAnex_AvailableDate
		FROM MuseumCollectionView mcv, ItemsLocationView Ilv
		WHERE mcv.MC_ItemAlphaKey= Ilv.ITL_ItemAlphaKey AND mcv.MC_ItemNumKey= Ilv.ITL_ItemNumKey AND Ilv.ITL_ItemLocation='Storage'
		) 
	UNION (
		SELECT mcv.MC_ItemAlphaKey, mcv.MC_ItemNumKey, mcv.MC_ItemName, mcv.MC_Type, mcv.MC_SubType, exlv.EXL_ExhEnddate AS IAnex_AvailableDate
		FROM MuseumCollectionView mcv, ExhibitionsLocationView exlv, ExhibitionsCollectionView ecxv
		WHERE mcv.MC_ItemAlphaKey= ecxv.EXC_ItemAlphaKey AND mcv.MC_ItemNumKey= ecxv.EXC_ItemNumKey AND ecxv.EXC_ExhName=exlv.EXL_ExhName
		) 

	ORDER BY IAnex_AvailableDate, MC_Type, MC_SubType;


------- *********** END OF CHANGES ON ASSIGNMENT 2 DATABASE *********************

------- ******** 	START OF ASSIGNMENT 3 ***************



-- Produce a report of all current and future exhibitions including the name of the exhibition, the dates it is happening (starting and ending dates), 
-- .. the maximum recommended capacity of the locations it is using, and the current number of works planned for it 

SELECT EXL_ExhName, EXL_ExhStartdate, EXL_ExhEnddate, ML_MaxNumWorks, COUNT(*) AS CurrentNumOfWorks
	FROM ExhibitionsView exv, ExhibitionsLocationView exlv, ExhibitionsCollectionView excv, MuseumLocationsView mlv
	    WHERE exv.EX_ExhName = exlv.EXL_ExhName AND exlv.EXL_ExhName = excv.EXC_ExhName
	      AND exlv.EXL_ExhLocation = mlv.ML_LocationName
	GROUP BY EXL_ExhName, EXL_ExhStartdate, EXL_ExhEnddate, ML_MaxNumWorks
	ORDER BY (EXL_ExhStartdate);



-- First, adding additional items to current running exhibition (i.e. Exhibition from Assignment 1) to top the number of items to the maximum capacity
-- .. the Exhibition location can hold.

-- Placing extra Items in Exhibition 1: A Glimpse from the Life of the Christ: Sacred Arts (7 Items inserted).
-- Start date: 2016-08-28     End date: 2016-12-01.
-- Note: This Exhibition is in Gallery B right now.

INSERT INTO ExhibitionsCollectionView(EXC_ExhName, EXC_ItemAlphaKey, EXC_ItemNumKey)
	SELECT 'A Glimpse from the Life of the Christ: Sacred Arts', MC_ItemAlphaKey, MC_ItemNumKey 
	FROM MuseumCollection
	WHERE (MC_ItemAlphaKey='PNTG' AND MC_ItemNumKey IN (1032, 1033, 1034, 1035, 1036, 1037, 1038));

-- For exhibitions that are currently under way, additional works should be added to those exhibitions on October 28, 2016. 
-- Recall: All items are initially placed in Storage even newly purchased item.

-- Now, we need to update ItemsLocation table to update the entry date of these additional items to October 28, 2016 instead of
-- ..  being the Starting date of the Exhibition they are located in.
UPDATE ItemsLocationView
	SET ITL_Startdate='2016-10-28'
	WHERE ITL_ItemLocation='Gallery_B' AND ITL_ItemAlphaKey='PNTG' AND ITL_ItemNumKey IN (1032, 1033, 1034, 1035, 1036, 1037, 1038) AND ITL_Startdate='2016-08-28';
-- Record that Items was taken out of Storage on October 28, 2016 (ITL_Enddate is updated)
-- Recall: All data are initially located in Storage.
UPDATE ItemsLocationView
	SET ITL_Enddate='2016-10-28'
	WHERE ITL_ItemLocation='Storage' AND ITL_ItemAlphaKey='PNTG' AND ITL_ItemNumKey IN (1032, 1033, 1034, 1035, 1036, 1037, 1038) AND ITL_Enddate= (SELECT MAX (ITL_Enddate) FROM ItemsLocationView 
	                                                                                            WHERE ITL_ItemLocation='Storage' AND ITL_ItemAlphaKey='PNTG' AND ITL_ItemNumKey IN (1032, 1033, 1034, 1035, 1036, 1037, 1038)); 

-- Placing additional Items in Exhibition 2: Still life in European Art (6 Items inserted).
-- Start date: 2016-07-20   End date: 2016-11-25.
-- Note: This Exhibition is in Gallery A right now.
INSERT INTO ExhibitionsCollectionView(EXC_ExhName, EXC_ItemAlphaKey, EXC_ItemNumKey)
	SELECT 'Still life in European Art', MC_ItemAlphaKey, MC_ItemNumKey 
	FROM MuseumCollection
	WHERE (MC_ItemAlphaKey='PNTG' AND MC_ItemNumKey IN (1054, 1055, 1056, 1057, 1058, 1059)); 

-- Now, we need to update ItemsLocation table to update the entry date of these additional items to October 28, 2016 instead of
-- .. being the Starting date of the Exhibition they are located in.
UPDATE ItemsLocationView
	SET ITL_Startdate='2016-10-28'
	WHERE ITL_ItemLocation='Gallery_A' AND ITL_ItemAlphaKey='PNTG' AND ITL_ItemNumKey IN (1054, 1055, 1056, 1057, 1058, 1059) AND ITL_Startdate='2016-07-20';

-- Record that Items was taken out of Storage on October 28, 2016 (ITL_Enddate is updated)
-- Recall: All data are initially located in Storage.
UPDATE ItemsLocationView
	SET ITL_Enddate='2016-10-28'
	WHERE ITL_ItemLocation='Storage' AND ITL_ItemAlphaKey='PNTG' AND ITL_ItemNumKey IN (1054, 1055, 1056, 1057, 1058, 1059) AND ITL_Enddate= (SELECT MAX (ITL_Enddate) FROM ItemsLocationView 
	                                                                                       					WHERE ITL_ItemLocation='Storage' AND ITL_ItemAlphaKey='PNTG' AND ITL_ItemNumKey IN (1054, 1055, 1056, 1057, 1058, 1059)); 

-- Placing Items in Exhibition 3: The Woven Bridges: Classical Textiles (8 Items inserted).
-- Start date: 2016-09-25    End date: 2016-12-28.
-- Note: This Exhibition is in Gallery C right now.
INSERT INTO ExhibitionsCollectionView(EXC_ExhName, EXC_ItemAlphaKey, EXC_ItemNumKey)
	SELECT 'The Woven Bridges: Classical Textiles', MC_ItemAlphaKey, MC_ItemNumKey 
	FROM MuseumCollection
	WHERE (MC_ItemAlphaKey='TXTL' AND MC_ItemNumKey IN (2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026));

-- Now, we need to update ItemsLocation table to update the entry date of these additional items to October 28, 2016 instead of
-- .. being the Starting date of the Exhibition they are located in.
UPDATE ItemsLocationView
	SET ITL_Startdate='2016-10-28'
	WHERE ITL_ItemLocation='Gallery_C' AND ITL_ItemAlphaKey='TXTL' AND ITL_ItemNumKey IN (2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026) AND ITL_Startdate='2016-09-25';

-- Record that Items was taken out of Storage on October 28, 2016 (ITL_Enddate is updated)
-- Recall: All data are initially located in Storage.
UPDATE ItemsLocationView
	SET ITL_Enddate='2016-10-28'
	WHERE ITL_ItemLocation='Storage' AND ITL_ItemAlphaKey='TXTL' AND ITL_ItemNumKey IN (2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026) AND ITL_Enddate= (SELECT MAX (ITL_Enddate) FROM ItemsLocationView 
	                                                                                            WHERE ITL_ItemLocation='Storage' AND ITL_ItemAlphaKey='TXTL' AND ITL_ItemNumKey IN (2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026)); 

-- On the day after the end of a current exhibition, all items in that exhibition are returned back to the Storage
-- This per Assignment 2 specification

INSERT INTO ItemsLocationView (ITL_ItemAlphaKey, ITL_ItemNumKey, ITL_ItemLocation, ITL_Startdate, ITL_Enddate)
	SELECT excv.EXC_ItemAlphaKey, excv.EXC_ItemNumKey, 'Storage', exlv.EXL_ExhEnddate+1, '2099-12-31'
		FROM ExhibitionsCollectionView excv, ExhibitionsView exv, ItemsLocationView Itlv, ExhibitionsLocationView exlv
		WHERE excv.EXC_ItemAlphaKey= Itlv.ITL_ItemAlphaKey AND excv.EXC_ItemNumKey= Itlv.ITL_ItemNumKey
		AND exlv.EXL_ExhLocation=Itlv.ITL_ItemLocation AND excv.EXC_ExhName IN ('A Glimpse from the Life of the Christ: Sacred Arts', 'Still life in European Art', 'The Woven Bridges: Classical Textiles')
												 AND excv.EXC_ExhName=exlv.EXL_ExhName AND excv.EXC_ExhName=exv.EX_ExhName;


-- Topping up Upcoming exhibitions i.e. Exhibitions which have not yet started.

-- Placing additional Items in future Exhibition 1: Madonna and Child: Samuel Kress Collection (8 Items inserted).
-- Start date: 2016-12-06    End date: 2017-05-06 (Check the output of the first query in this Assignment.)
-- Note: This Exhibition is planned to be Gallery B 
INSERT INTO ExhibitionsCollectionView(EXC_ExhName, EXC_ItemAlphaKey, EXC_ItemNumKey)
	SELECT 'Madonna and Child: Samuel Kress Collection', MC_ItemAlphaKey, MC_ItemNumKey 
	FROM MuseumCollection
	WHERE (MC_ItemAlphaKey='PNTG' AND MC_ItemNumKey IN (1032, 1033, 1034, 1035, 1036, 1037, 1038, 1039)); 
		  

-- Placing additional Items in future Exhibition 2: English Clocks: The Frick Collection (7 Items inserted).
-- Start date: 2016-11-30     End date: 2017-03-30.
-- Note: This Exhibition is planned to be Gallery B (Check the output of the first query in this Assignment.)
INSERT INTO ExhibitionsCollectionView(EXC_ExhName, EXC_ItemAlphaKey, EXC_ItemNumKey)
	SELECT 'English Clocks: The Frick Collection', MC_ItemAlphaKey, MC_ItemNumKey 
	FROM MuseumCollection
	WHERE (MC_ItemAlphaKey='CLCK' AND MC_ItemNumKey IN (4010, 4011, 4012, 4013, 4014, 4015, 4016));

-- Placing additional Items in future Exhibition 3: La beauté de la Campagne: Best 18 landscape paintings (6 Items inserted).
-- Start date: 2017-01-02      End date: 2017-04-02.
-- Note: This Exhibition is planned to be Gallery C (Check the output of the first query in this Assignment.)
INSERT INTO ExhibitionsCollectionView(EXC_ExhName, EXC_ItemAlphaKey, EXC_ItemNumKey)
	SELECT 'La beauté de la Campagne: Best 18 landscape paintings', MC_ItemAlphaKey, MC_ItemNumKey 
	FROM MuseumCollection
	WHERE (MC_ItemAlphaKey='PNTG' AND MC_ItemNumKey IN (1060, 1061, 1063, 1064, 1065, 1066));


-- We again produce a report for all current and future exhibitions including the name of the exhibition, the dates it is happening (starting and ending dates), 
-- .. the maximum recommended capacity of the locations it is using, and the current number of works planned for it 
SELECT EXL_ExhName, EXL_ExhStartdate, EXL_ExhEnddate, ML_MaxNumWorks, COUNT(*) AS CurrentNumOfWorks
	FROM ExhibitionsView exv, ExhibitionsLocationView exlv, ExhibitionsCollectionView excv, MuseumLocationsView mlv
	    WHERE exv.EX_ExhName = exlv.EXL_ExhName AND exlv.EXL_ExhName = excv.EXC_ExhName
	      AND exlv.EXL_ExhLocation = mlv.ML_LocationName
	GROUP BY EXL_ExhName, EXL_ExhStartdate, EXL_ExhEnddate, ML_MaxNumWorks
	ORDER BY (EXL_ExhStartdate);
