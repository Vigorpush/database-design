Steps to run Assignment 3 database the provided sql scripts.

1. Download the submitted Assignment3.zip file and unzipped it on your local directory
2. Be sure you to be in ./Assignment3
3. Connect to a PostgresSQL database server
4. execute the following command 
    
          \i 'Assignment3.sql'

This script will run five sql script files:

\i 'C355A31.sql' —- This script initially runs Assignment2.sql script
\i 'C355A32.sql'
\i 'C355A33.sql'
\i 'C355A34.sql'
\i 'C355A35.sql'

This will buildup the database from zero up to the state it's currently on my database university server.

Assignment2.sql is the script to buildup the database from zero up to Assignment 2 ONLY. So, assignment 3 will start from this point and modify on Assignment 2 database.

