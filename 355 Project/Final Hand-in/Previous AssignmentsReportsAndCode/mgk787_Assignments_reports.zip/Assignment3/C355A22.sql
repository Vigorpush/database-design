-- Name : Mohamed Kassem
-- NSID: mgk787
-- Student no.: 11129292
-- Assignment 2 (Part 2)
-- File Name: C355A22.sql



DROP TABLE IF EXISTS MuseumLocationsState CASCADE;
DROP TABLE IF EXISTS KeyWordCount CASCADE;
DROP TABLE IF EXISTS WorksColors CASCADE;
DROP TABLE IF EXISTS ItemsOwnership CASCADE;
DROP DOMAIN IF EXISTS Ownership_Status CASCADE;
DROP DOMAIN IF EXISTS BorrowedFrom CASCADE;
DROP DOMAIN IF EXISTS LocationState CASCADE;
DROP DOMAIN IF EXISTS FromDate CASCADE;
DROP DOMAIN IF EXISTS ToDate CASCADE;
DROP DOMAIN IF EXISTS ItemColor CASCADE;



-- 2. A) Expanded works

-- Create a new ItemsOwnership  table to record the status of ownership for each item and Lenders Names. 
CREATE DOMAIN Ownership_Status AS CHAR (50) CHECK (VALUE IN ('OWNED-PURCHASED', 'LONG TERM BORROWED', 'POTENTIAL BORROWING', 'SOLD'));
CREATE DOMAIN BorrowedFrom AS CHAR (50) DEFAULT 'NONE';

CREATE TABLE ItemsOwnership (
	ITO_ItemAlphaKey ItemAlphaKey,
	ITO_ItemNumKey ItemNumKey,
	ITO_Ownership_Status Ownership_Status,
	ITO_BorrowedFrom BorrowedFrom,


	PRIMARY KEY(ITO_ItemAlphaKey, ITO_ItemNumKey,ITO_Ownership_Status),
	FOREIGN KEY (ITO_ItemAlphaKey, ITO_ItemNumKey)
			REFERENCES MuseumCollection (MC_ItemAlphaKey, MC_ItemNumKey) 
			ON UPDATE CASCADE 
			ON DELETE CASCADE
);


CREATE VIEW ItemsOwnershipView
		AS SELECT ITO_ItemAlphaKey, ITO_ItemNumKey, ITO_Ownership_Status, ITO_BorrowedFrom
		FROM ItemsOwnership
		;



-- 2. B) Expanded facilities


-- This is an expanded version of our museum after adding the new Gallery.
-- 
--           50m        50m
--      o----------o-----------o
--      |          /   Lobby   / 20m 
--      |          |           |     50m
--      |          o--/-----/--o-----------o
--      |          |     |     |           |
--      |          |  A  |  B  \           |
-- 150m |  Storage |     /     |     D     | 65m
--      |          |     |     |           |
--      |          |     |     |           |
--      |          |--/--o--/--o-----------o
--      |          | 25m   25m |
--      |          |           |
--      |          |     C     | 65m
--      |          |           |
--      |          |           |
--      o----------o-----------o

-- Create a new Gallery with name Gallery_D with a suggested minimum of 15 works and suggested maximum of 25 works.
-- This Gallery has one door.
INSERT INTO MuseumLocationsView (ML_LocationName, ML_AreaSquareMeter, ML_NumOfDoors, ML_MinNumWorks, ML_MaxNumWorks)
	VALUES ('Gallery_D', 3250, 1, 15, 25);

-- Insert data regarding the connectivity of the new Gallery with other locations in the Museum. 
INSERT INTO LocationsConnectionsView (LC_LocationName, LC_ConnectedTo)
	VALUES ('Gallery_B', 'Gallery_D'),
	       ('Gallery_D', 'Gallery_B');



--Create a new table along with its view named: MuseumLocationsState and MuseumLocationsStateview. 
-- This table record the status of the museum location with the passage of time. 

CREATE DOMAIN LocationState AS CHAR (25) CHECK (VALUE IN ('OPEN', 'CLOSED', 'UNDER CONSTRUCTION', 'MAINTENANCE'));
CREATE DOMAIN FromDate AS DATE CHECK (VALUE >= '1990-6-01');
CREATE DOMAIN ToDate AS DATE;

CREATE TABLE MuseumLocationsState (
	MLS_LocationName LocationName,
	MLS_LocationState LocationState,
	MLS_FromDate DATE,
	MLS_ToDate DATE,

	FOREIGN KEY (MLS_LocationName)
			REFERENCES MuseumLocations (ML_LocationName) 
			ON UPDATE CASCADE 
			ON DELETE CASCADE

	);

CREATE VIEW MuseumLocationsStateView
		AS SELECT MLS_LocationName, MLS_LocationState, MLS_FromDate, MLS_ToDate 
		FROM MuseumLocationsState
		ORDER BY MLS_LocationName
		;

-- Insert the state of all "current" locations i.e. Storage, Lobby, Gallery_A, Gallery_B, Gallery_C.
INSERT INTO MuseumLocationsStateView (MLS_LocationName, MLS_LocationState, MLS_FromDate, MLS_ToDate )
	VALUES ('Storage', 'OPEN', '1990-7-01', CAST (now() AS DATE)),
	       ('Lobby','OPEN' ,'1990-07-1', CAST (now() AS DATE)),
	       ('Gallery_A','OPEN' ,'1990-07-1', CAST (now() AS DATE)),
	       ('Gallery_B','OPEN' ,'1990-07-1', CAST (now() AS DATE)),
	       ('Gallery_C','OPEN' ,'1990-07-1', CAST (now() AS DATE));

-- Insert the state of the newly opened gallery: Gallery_D
INSERT INTO MuseumLocationsStateView (MLS_LocationName, MLS_LocationState, MLS_FromDate, MLS_ToDate )
	VALUES ('Gallery_D', 'UNDER CONSTRUCTION', '2016-10-19', '2016-12-19');

-- After two months from 2016-10-19 (i.e. the date Assignment 2 was assigned), the new Gallery will be OPEN.
INSERT INTO MuseumLocationsStateView (MLS_LocationName, MLS_LocationState, MLS_FromDate, MLS_ToDate )
	VALUES ('Gallery_D', 'OPEN', '2016-12-20', DEFAULT);




-- 2. C) More detailed information on items
	 

-- Create a table to COUNT the number of times each word in the MC_ItemDescription coloum appears.
-- 
CREATE TABLE KeyWordCount
	AS (SELECT Word, COUNT(*) AS WordCounter
	-- regexp_split_to_table() is a postgres String function that plit string using a POSIX regular expression as the delimiter.
	FROM (SELECT lower(regexp_split_to_table(MC_ItemDescription, '\s')) as Word
		FROM MuseumCollectionView
	) subquery
	GROUP BY Word
	ORDER BY WordCounter DESC);


-- Query 1 sorted in order of number of different items that the word appears in (to identify the most important words)
--SELECT Word, WordCounter, COUNT(*) AS NumOfRecords
--	FROM KeyWordCount, MuseumCollection
--	WHERE MC_ItemDescription LIKE '%' || Word || '%'
--	GROUP BY Word, WordCounter
--	ORDER BY NumOfRecords DESC;


-- Query 2 sorted in alphabetic order of the words (to identify similar words, i.e. variations on a single word)
--SELECT Word, WordCounter, COUNT(*) AS NumOfRecords
--	FROM KeyWordCount, MuseumCollection
--	WHERE MC_ItemDescription LIKE '%' || word || '%'
--	GROUP BY Word, WordCounter
--	ORDER BY Word ASC;


-- Create a new table WorksColors based on the result of our full text search.
CREATE DOMAIN ItemColor AS CHAR (15) NOT NULL; 
CREATE TABLE WorksColors (
		WC_ItemAlphaKey ItemAlphaKey,
		WC_ItemNumKey ItemNumKey,
		WC_ItemColor ItemColor,
	
		FOREIGN KEY (WC_ItemAlphaKey, WC_ItemNumKey)
			REFERENCES MuseumCollection (MC_ItemAlphaKey, MC_ItemNumKey) 
			ON UPDATE CASCADE 
			ON DELETE CASCADE
	);


CREATE VIEW WorksColorsView
		AS SELECT wc.WC_ItemAlphaKey, wc.WC_ItemNumKey, wc.WC_ItemColor
		FROM WorksColors wc
		;


