-- Name : Mohamed Kassem
-- NSID: mgk787
-- Student no.: 11129292
-- Assignment 3 (Part 3)
-- File Name: C355A33.sql


DROP DOMAIN IF EXISTS itemStartdateTime CASCADE;
DROP DOMAIN IF EXISTS itemEnddateTime CASCADE;


-- 3. Recording history

-- **** Copying from the Assingment part3.

--It is important that you can identify the history of
--different locations and exhibitions of a work on a date & time basis [the location of works is very important]
--It is important for insurance purposes that you know the exact time (minute by minute) when a work moved between locations. 
--Given that the museum is small, the time that it arrives at a new location can also be used as the time it left its previous location.

--You should have the day by day information available for previous moves and this is good enough for those moves.
--You should start to use minute by minute information for all moves in the future.

-- *********** SOLUTION ********

-- // ********* ItemsLocationView (i.e. ItemsLocation table) already records the day by day moves of all items in the museum. 

-- Uncomment
-- SELECT * FROM ItemsLocationView

-- What we need now is to record the exact time (minute by minute) when a work moved between locations. 

DROP VIEW ItemsLocationView CASCADE;


CREATE DOMAIN itemStartdateTime AS TIMESTAMP CHECK (VALUE >= '1990-07-01 00:00:00');
CREATE DOMAIN itemEnddateTime AS TIMESTAMP CHECK (VALUE >= '1990-07-01 00:00:00');

ALTER TABLE ItemsLocation ALTER COLUMN ITL_Startdate TYPE itemStartdateTime;
ALTER TABLE ItemsLocation ALTER COLUMN ITL_Enddate TYPE itemStartdateTime;

-- Recreate the ItemsLocationView after altering the ItemsLocation table.
CREATE OR REPLACE VIEW ItemsLocationView
	AS SELECT ITL_ItemAlphaKey, ITL_ItemNumKey, ITL_ItemLocation, ITL_Startdate, ITL_Enddate
	FROM ItemsLocation
	ORDER BY ITL_ItemAlphaKey, ITL_ItemNumKey, ITL_Startdate, ITL_Enddate
	;


-- Dropping the ItemsLocationView will lead to the drop of two other dependent view from Assignment 1. Below are the dropped views which I recreated again in this part of the assignment. 
--     ItemsInStoragePrivateView (originally created in Assignment 1, part 3)
--     ItemsAvailiabiltyNewExhibitions (originally created in Assignment 1, part 3)

-- Recreating ItemsInStoragePrivateView

CREATE OR REPLACE VIEW  ItemsInStoragePrivateView
AS SELECT mcv.MC_ItemAlphaKey, mcv.MC_ItemNumKey, mcv.MC_ItemName, mcv.MC_ItemInsuranceValue, 
		  Itv.ITL_ItemLocation
		FROM MuseumCollectionView mcv, ItemsLocationView Itv
		WHERE mcv.MC_ItemAlphaKey=Itv.ITL_ItemAlphaKey AND mcv.MC_ItemNumKey=Itv.ITL_ItemNumKey AND
			  Itv.ITL_ItemLocation='Storage';
		
-- Recreating ItemsAvailiabiltyNewExhibitions
CREATE OR REPLACE VIEW ItemsAvailiabiltyNewExhibitions
	AS 
		(SELECT mcv.MC_ItemAlphaKey, mcv.MC_ItemNumKey, mcv.MC_ItemName, mcv.MC_Type, mcv.MC_SubType, CAST (now() AS DATE) AS IAnex_AvailableDate
		FROM MuseumCollectionView mcv, ItemsLocationView Ilv
		WHERE mcv.MC_ItemAlphaKey= Ilv.ITL_ItemAlphaKey AND mcv.MC_ItemNumKey= Ilv.ITL_ItemNumKey AND Ilv.ITL_ItemLocation='Storage'
		) 
	UNION (
		SELECT mcv.MC_ItemAlphaKey, mcv.MC_ItemNumKey, mcv.MC_ItemName, mcv.MC_Type, mcv.MC_SubType, exlv.EXL_ExhEnddate AS IAnex_AvailableDate
		FROM MuseumCollectionView mcv, ExhibitionsLocationView exlv, ExhibitionsCollectionView ecxv
		WHERE mcv.MC_ItemAlphaKey= ecxv.EXC_ItemAlphaKey AND mcv.MC_ItemNumKey= ecxv.EXC_ItemNumKey AND ecxv.EXC_ExhName=exlv.EXL_ExhName
		) 

	ORDER BY IAnex_AvailableDate, MC_Type, MC_SubType;



-- Produce a query that lists the different locations that a given work was/is/will be in between two dates
-- The list should contain one line for each location including the date and time the work arrived at that location and the the date and time it left that location. 
-- Manually choose one or more works (currently in an exhibition) to use to demonstrate the query for the period between Nov 1, 2015 and Nov. 1, 2016 
-- (NOTE: all works should have been in storage from when they were acquired by your museum until the first exhibits defined in Assignment 1 and in the new exhibitions that you defined above) 

-- ** ALL THAT WORK HAVE BEEN DONE PREVIOUSLY. All data regarding the moves of Works between Exhibitions and Exhibition and Storage are
-- .. record in ItemsLocationView (i.e. ItemsLocation table) - Check report for more details.

-- This query list the different location item PNTG 1032 and 1007 were in between '2015-11-01' AND '2016-11-01'
SELECT ITL_ItemAlphaKey, ITL_ItemNumKey, ITL_ItemLocation, ITL_Startdate, ITL_Enddate
	FROM ItemsLocationView
	WHERE (ITL_ItemAlphaKey='PNTG' AND ITL_ItemNumKey IN (1032, 1007)) 
			AND (ITL_Startdate BETWEEN '2015-11-01' AND '2016-11-01')
    ORDER BY ITL_ItemAlphaKey, ITL_ItemNumKey, ITL_Startdate;



--Produce a query that lists all the works found in an exhibition between two dates
--The list should include the names of each work and the starting and ending date when the work was in the exhibition (sorted in order of starting dates and alphabetically within the same starting date)
--Demonstrate the query for the period between Nov 1, 2015 and Nov 1, 2016 for the exhibition that one of the above manually chosen works is currently part of.

-- For the exhibition 'A Glimpse from the Life of the Christ: Sacred Arts'.
-- Recall: A Glimpse from the Life of the Christ: Sacred Arts runs in Gallery_B  from 2016-08-28 to 2016-11-25. 

SELECT EXC_ItemAlphaKey, EXC_ItemNumKey, MC_ItemName, ITL_Startdate, ITL_Enddate
FROM ExhibitionsCollectionView excv, MuseumCollectionView mcv, ItemsLocationView itlv, ExhibitionsLocationView exlv
WHERE excv.EXC_ItemAlphaKey=mcv.MC_ItemAlphaKey AND excv.EXC_ItemNumKey=mcv.MC_ItemNumKey AND excv.EXC_ItemAlphaKey=itlv.ITL_ItemAlphaKey AND excv.EXC_ItemNumKey=itlv.ITL_ItemNumKey
      AND excv.EXC_ExhName='A Glimpse from the Life of the Christ: Sacred Arts' AND excv.EXC_ExhName=exlv.EXL_ExhName AND exlv.EXL_ExhLocation=itlv.ITL_ItemLocation
      AND (ITL_Startdate BETWEEN '2015-11-01' AND '2016-11-01')
      ORDER BY EXC_ItemAlphaKey, EXC_ItemNumKey, ITL_Startdate;

-- Another test between Nov 1, 2015 and Oct 25, 2015 (The exhibit should have only 9 works in this period)- See reprot for explanation.
SELECT EXC_ItemAlphaKey, EXC_ItemNumKey, MC_ItemName, ITL_Startdate, ITL_Enddate
FROM ExhibitionsCollectionView excv, MuseumCollectionView mcv, ItemsLocationView itlv, ExhibitionsLocationView exlv
WHERE excv.EXC_ItemAlphaKey=mcv.MC_ItemAlphaKey AND excv.EXC_ItemNumKey=mcv.MC_ItemNumKey AND excv.EXC_ItemAlphaKey=itlv.ITL_ItemAlphaKey AND excv.EXC_ItemNumKey=itlv.ITL_ItemNumKey
      AND excv.EXC_ExhName='A Glimpse from the Life of the Christ: Sacred Arts' AND excv.EXC_ExhName=exlv.EXL_ExhName AND exlv.EXL_ExhLocation=itlv.ITL_ItemLocation
      AND (ITL_Startdate BETWEEN '2015-11-01' AND '2016-10-25');   


--Produce a query that lists all the exhibitions that make use of a location between two dates
--The list should contain one line for each separate use of the location including its starting and ending date sorted in order of starting dates
--uses include exhibitions and periods when the location is closed due to changing exhibitions (which should be named as "closed for changing exhibitions")
--If a particular exhibition returns to a location after some period of absence, it should be listed multiple times in this listing
--demonstrate the query for the period between Nov 1, 2015 and Nov 1, 2016  for the location where one the above manually chosen works is currently being exhibited.

SELECT EXL_ExhName, EXL_ExhLocation, EXL_ExhStartdate, EXL_ExhEnddate
FROM ExhibitionsLocationView
WHERE EXL_ExhLocation='Gallery_B' AND (EXL_ExhStartdate BETWEEN '2015-11-01' AND '2016-11-01')
ORDER BY EXL_ExhStartdate;

-- ExhibitionsLocation table already allows an Exhibition to be listed multiple times as long as it has a unique starting and ending date. 
-- In ExhibitionsLocation table, the following attributes are all primary keys (EXL_ExhName, EXL_ExhLocation, EXL_ExhStartdate, EXL_ExhEnddate)




