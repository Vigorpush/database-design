-- Name : Mohamed Kassem
-- NSID: mgk787
-- Student no.: 11129292
-- Assignment 3 (Part 2)
-- File Name: C355A32.sql



-- 2. evolving collection using a text file named C355A32.txt 

-- Your museum has just purchased 15 additional new works on October 25
\copy museumcollection FROM 'C355A32-1.txt' -- This line will add 15 new items to our database collection (i.e. MuseumCollection Table)
\copy WorksMedium FROM 'C355A32-2.txt' -- -- This line will add data regarding work medium/media for the 15 newly purchased items.

-- Now, we have to add these  15 new items to ItemsOwnershipView (i.e. ItemsOwnership table) with Ownership_Status='OWNED-PURCHASED',
-- ITO_BorrowedFrom = 'NONE', and ITO_Acquisition_Borrowing_Date= 2016-10-25 (as per Assignment specification) 
-- .. and ITO_Returning_SellingDate= NULL(No returning date for an owned or purchased items)

INSERT INTO ItemsOwnershipView (ITO_ItemAlphaKey, ITO_ItemNumKey, ITO_Ownership_Status, ITO_BorrowedFrom, ITO_Acquisition_Borrowing_Date, ITO_Returning_SellingDate)
	SELECT MC_ItemAlphaKey, MC_ItemNumKey, 'OWNED-PURCHASED', 'NONE','2016-10-25', NULL
	FROM MuseumCollectionView
	WHERE (MC_ItemAlphaKey='PNTG' AND MC_ItemNumKey IN (1006, 1009, 1013, 1015, 1017, 1019, 1023)) OR
		  (MC_ItemAlphaKey='TXTL' AND MC_ItemNumKey IN (2011, 2027)) OR
		  (MC_ItemAlphaKey='SCLP' AND MC_ItemNumKey IN (3012, 3013, 3014, 3015, 3016, 3016));


-- It has also sold (de-collected) 3 works (that have not been exhibited since the start of the database) to other museums (on October 21).
-- By checking the ItemsLocationView (i.e. ItemsLocation Table), we can find that the following four items have not been exhibited anytime since
-- there acquisition (i.e. they have been in storage since their acquisition.)
--| PNTG             |           1075 | Storage          | 2000-06-26    | 2099-12-31  |
--| PNTG             |           1076 | Storage          | 1996-06-22    | 2099-12-31  |
--| PNTG             |           1077 | Storage          | 1997-07-12    | 2099-12-31  |
--| PNTG             |           1078 | Storage          | 1999-09-29    | 2099-12-31  |

-- We will de-collect the following three items PNTG 1076, PNTG 1077, PNTG 1078
UPDATE ItemsOwnershipView
	SET ITO_Returning_SellingDate ='2016-10-21', ITO_Ownership_Status='SOLD'
	WHERE ITO_ItemAlphaKey='PNTG' AND ITO_ItemNumKey IN (1076, 1077, 1078);

-- We now need to update the the Enddate of these three sold items in the ItemsLocation Table to '2016-10-21'.
-- Note: These Items were in Storage before they are sold.
UPDATE ItemsLocationView
	SET ITL_Enddate= '2016-10-21'
	WHERE ITL_ItemAlphaKey='PNTG' AND ITL_ItemNumKey IN (1076, 1077, 1078) AND ITL_ItemLocation='Storage';