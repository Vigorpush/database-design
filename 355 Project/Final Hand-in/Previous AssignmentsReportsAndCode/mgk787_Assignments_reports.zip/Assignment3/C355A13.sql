-- Name : Mohamed Kassem
-- NSID: mgk787
-- Student no.: 11129292
-- Assignment 1 (Part 3)
-- File Name: C355A13.sql



-- WARNING: running this postgres script will produce all of output data on the terminal screen
-- .. There exit some SELECT * FROM .... statements here.

\pset pager off
\pset format wrapped
\pset border 3

-- Required: Produce for the head of the museum a listing of all works 
-- .. (including their identifier, name, and insurance value) that are currently in storage.

-- Create a View for the Items In Storage (Read Only View)
CREATE VIEW ItemsInStoragePrivateView
AS SELECT mcv.MC_ItemAlphaKey, mcv.MC_ItemNumKey, mcv.MC_ItemName, mcv.MC_ItemInsuranceValue, 
		  Itv.ITL_ItemLocation
		FROM MuseumCollectionView mcv, ItemsLocationView Itv
		WHERE mcv.MC_ItemAlphaKey=Itv.ITL_ItemAlphaKey AND mcv.MC_ItemNumKey=Itv.ITL_ItemNumKey AND
			  Itv.ITL_ItemLocation='Storage';
		;

-- Show all items currently in store with their keys, names and insurance value.
--SELECT * FROM ItemsInStoragePrivateView;




-- Required: Produce for the public a listing of all exhibitions (including name, description, location, and number of works)
CREATE VIEW ExhibitionsListPublicView
AS SELECT EX_ExhName, EX_ExhLocation, (SELECT COUNT(*)
													FROM ExhibitionsCollectionView
													WHERE EXC_ExhName = EX_ExhName)
													AS EX_NumOfWorks, EX_ExhDescription
FROM Exhibitions;



-- Show a listing of all exhibitions (including name, description, location, and number of works).
--SELECT * FROM ExhibitionsListPublicView;


-- Required: Produce for the public a listing of all publicly available data on all works in each of the exhibitions 
-- .. sorted by exhibition and by the name of the work


-- Create view for the public listing data about works that are in exhibitions,
-- sorted by exhibition and work name

CREATE VIEW ExhibitionsCollectionInfoPublicView
	AS SELECT ecxv.EXC_ExhName, mcv.MC_ItemAlphaKey, mcv.MC_ItemNumKey, mcv.MC_ItemName, mcv.MC_Type, mcv.MC_SubType, 
		mcv.MC_ItemSource, mcv.MC_ItemComplYear, mcv.MC_ItemAcquisitionDate, mcv.MC_ItemInsuranceValue, 
		mcv.MC_ItemDescription 
	FROM MuseumCollectionView mcv, ExhibitionsCollectionView ecxv
	WHERE mcv.MC_ItemAlphaKey = ecxv.EXC_ItemAlphaKey AND mcv.MC_ItemNumKey = ecxv.EXC_ItemNumKey 
	ORDER BY ecxv.EXC_ExhName, mcv.MC_ItemName;



-- Show a listing of all publicly available data on all works in each of the exhibitions 
-- .. sorted by exhibition and by the name of the work
--SELECT * FROM ExhibitionsCollectionInfoPublicView;



-- Required: Produce for a curator a listing of works sorted by when they are available for use in a new exhibition and by classification and by name of the work
-- Note: Items which will be available immediately for current use (i.e. not in any running exhibitions), will be listed with an available date = 2016-10-05
-- ..(i.e. the assignment deadline)

CREATE VIEW ItemsAvailiabiltyNewExhibitions
	AS 
		(SELECT mcv.MC_ItemAlphaKey, mcv.MC_ItemNumKey, mcv.MC_ItemName, mcv.MC_Type, mcv.MC_SubType, CAST (now() AS DATE) AS IAnex_AvailableDate
		FROM MuseumCollectionView mcv, ItemsLocationView Ilv
		WHERE mcv.MC_ItemAlphaKey= Ilv.ITL_ItemAlphaKey AND mcv.MC_ItemNumKey= Ilv.ITL_ItemNumKey AND Ilv.ITL_ItemLocation='Storage'
		) 
	UNION (
		SELECT mcv.MC_ItemAlphaKey, mcv.MC_ItemNumKey, mcv.MC_ItemName, mcv.MC_Type, mcv.MC_SubType, exv.EX_ExhEnddate AS IAnex_AvailableDate
		FROM MuseumCollectionView mcv, ExhibitionsView exv, ExhibitionsCollectionView ecxv
		WHERE mcv.MC_ItemAlphaKey= ecxv.EXC_ItemAlphaKey AND mcv.MC_ItemNumKey= ecxv.EXC_ItemNumKey AND ecxv.EXC_ExhName=exv.EX_ExhName
		) 

	ORDER BY IAnex_AvailableDate, MC_Type, MC_SubType;
			


-- Shows a a listing of works sorted by when they are available for use in a new exhibition and by classification and by name of the work 
--SELECT * FROM ItemsAvailiabiltyNewExhibitions;

-- Required: Produce for the curator a listing of the amount of additional works that could be added to each 
-- exhibit based on the unused capacity of the galleries that they are currently in.
-- Note: ExhibitionsListPublicView  is created at the top of this file 
CREATE VIEW ExhibitionsAdditionalWorksView
	AS SELECT elpv.EX_ExhName, (mlv.ML_MaxNumWorks-elpv.EX_NumOfWorks) AS NumOfAdditionalWork
	FROM  MuseumLocationsView mlv, ExhibitionsListPublicView  elpv
	WHERE elpv.EX_ExhLocation=mlv.ML_LocationName
	;



-- Shows a listing of the amount of additional works that could be added to each 
-- .. exhibit based on the unused capacity of the galleries that they are currently in.
--SELECT * FROM ExhibitionsAdditionalWorksView;




--- Oh, boy! That was a long Assingmnet :).
-- Thanks,










