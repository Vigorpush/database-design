-- Name : Mohamed Kassem
-- NSID: mgk787
-- Student no.: 11129292
-- Assignment 2 (Part 2)
-- File Name: C355A22.sql



DROP TABLE IF EXISTS MuseumLocationsAvailiability CASCADE;
DROP TABLE IF EXISTS WORDS CASCADE;
DROP DOMAIN IF EXISTS LocationState CASCADE;
DROP DOMAIN IF EXISTS FromDate CASCADE;
DROP DOMAIN IF EXISTS ToDate CASCADE;



-- 2.b expanded facilities


-- Here's our updated museum (not to scale):
-- 
--           50m        50m
--      o----------o-----------o
--      |          /   Lobby   / 20m --> EXIT
--      |          |           |     50m
--      |          o--/-----/--o-----------o
--      |          |     |     |           |
--      |          |  A  |  B  \           |
-- 150m |  Storage |     /     |     D     | 65m
--      |          |     |     |           |
--      |          |     |     |           |
--      |          |--/--o--/--o-----------o
--      |          | 25m   25m |
--      |          |           |
--      |          |     C     | 65m
--      |          |           |
--      |          |           |
--      o----------o-----------o



INSERT INTO MuseumLocationsView (ML_LocationName, ML_AreaSquareMeter, ML_NumOfDoors, ML_MaxNumWorks, ML_MinNumWorks)
	VALUES ('Gallery_D', 3250, 1, 15, 25);


CREATE DOMAIN LocationState AS CHAR (25) CHECK (VALUE IN ('OPEN', 'CLOSED', 'UNDER CONSTRUCTION', 'MAINTENANCE'));
CREATE DOMAIN FromDate AS DATE CHECK (VALUE >= '1990-6-01');
CREATE DOMAIN ToDate AS DATE;

CREATE TABLE MuseumLocationsAvailiability (
	MLA_LocationName LocationName,
	MLA_LocationState LocationState,
	MLA_FromDate DATE,
	MLA_ToDate DATE,

	FOREIGN KEY (MLA_LocationName)
			REFERENCES MuseumLocations (ML_LocationName) 
			ON UPDATE CASCADE 
			ON DELETE CASCADE

	);

CREATE VIEW MuseumLocationsAvailiabilityView
		AS SELECT MLA_LocationName, MLA_LocationState, MLA_FromDate, MLA_ToDate 
		FROM MuseumLocationsAvailiability
		ORDER BY MLA_LocationName
		;

-- Update the availability of all "current" locations i.e. Storage, Lobby, Gallery_A, Gallery_B, Gallery_B.
-- Storage opened before the first date of first acquisition. 

INSERT INTO MuseumLocationsAvailiabilityView (MLA_LocationName, MLA_LocationState, MLA_FromDate, MLA_ToDate )
	VALUES ('Storage', 'OPEN', '1990-6-01', CAST (now() AS DATE)),
	       ('Lobby','OPEN' ,'1990-07-1', CAST (now() AS DATE)),
	       ('Gallery_A','OPEN' ,'1990-07-1', CAST (now() AS DATE)),
	       ('Gallery_B','OPEN' ,'1990-07-1', CAST (now() AS DATE)),
	       ('Gallery_C','OPEN' ,'1990-07-1', CAST (now() AS DATE));


-- Insert info, about the new gallery

INSERT INTO MuseumLocationsAvailiabilityView (MLA_LocationName, MLA_LocationState, MLA_FromDate, MLA_ToDate )
	VALUES ('Gallery_D', 'UNDER CONSTRUCTION', '2016-10-19', '2016-12-19');

-- After two months from 2016-10-19 (i.e. the date Assignment 2 was assigned), the new Gallery will be OPEN.
INSERT INTO MuseumLocationsAvailiabilityView (MLA_LocationName, MLA_LocationState, MLA_FromDate, MLA_ToDate )
	VALUES ('Gallery_D', 'OPEN', '2016-12-20', DEFAULT);


---- No changes to the table connectedTO
-- Insert info. about the new gallery_D

INSERT INTO LocationsConnectionsView (LC_LocationName, LC_ConnectedTo)
	VALUES ('Gallery_B', 'Gallery_D'),
	       ('Gallery_D', 'Gallery_B');
	  
-- discuss that you could have dropped the attribute NumOfDoors from MuseumLocation Table. 


CREATE TABLE WORDS
	AS (SELECT word, COUNT(*) AS count
	FROM (SELECT lower(regexp_split_to_table(MC_ItemDescription, '\s')) as word
		FROM MuseumCollection
	) subquery
	GROUP BY word
	ORDER BY count DESC);


-- Now join this to figure out the number of records with a particular word.
-- We produce two copies, one that is sorted by count:
SELECT word, count, COUNT(*) AS records
	FROM WORDS, MuseumCollection
	WHERE MC_ItemDescription LIKE '%' || word || '%'
	GROUP BY word, count
	ORDER BY count DESC;

-- and one that is sorted alphabetically (unfortunately, there's a lot of
-- crap characters polluting the list, making it unreadable):
SELECT word, count, COUNT(*) AS records
	FROM WORDS, MuseumCollection
	WHERE MC_ItemDescription LIKE '%' || word || '%'
	GROUP BY word, count
	ORDER BY word ASC;







ALTER TABLE MuseumCollection ADD COLUMN textsearchable_index_col tsvector;
UPDATE MuseumCollection SET textsearchable_index_col = to_tsvector(MC_ItemDescription);


--select to_tsvector(MC_ItemDescription) from MuseumCollection;


--select * from ts_stat('select to_tsvector(MC_ItemDescription) from MuseumCollection')
--order by ts_stat.nentry desc;

select  mc.MC_ItemAlphaKey, mc.MC_ItemNumKey, ts_stat.word, ts_stat.nentry ,COUNT(*) AS records
FROM MuseumCollection mc, ts_stat('select to_tsvector(MC_ItemDescription) from MuseumCollection')
GROUP BY mc.MC_ItemAlphaKey, mc.MC_ItemNumKey, ts_stat.word, ts_stat.nentry
LIMIT 200;
--order by mc.MC_ItemAlphaKey, mc.MC_ItemNumKey, ts_stat.nentry desc;









