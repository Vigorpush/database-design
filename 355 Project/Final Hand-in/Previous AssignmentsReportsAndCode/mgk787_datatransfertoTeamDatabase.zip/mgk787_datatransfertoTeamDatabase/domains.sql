DROP DOMAIN IF EXISTS mgk787.NS_WorkCharID CASCADE;
CREATE DOMAIN mgk787.NS_WorkCharID as varchar(10);


DROP DOMAIN IF EXISTS mgk787.NS_WorkNumID CASCADE;
CREATE DOMAIN mgk787.NS_WorkNumID as bigint;


DROP DOMAIN IF EXISTS mgk787.NS_DatabaseEntryLocation CASCADE;
CREATE DOMAIN mgk787.NS_DatabaseEntryLocation as varchar(60);


DROP DOMAIN IF EXISTS mgk787.NS_WorkName CASCADE;
CREATE DOMAIN mgk787.NS_WorkName AS varchar(200);


DROP DOMAIN IF EXISTS mgk787.NS_WorkDescription CASCADE;
CREATE DOMAIN mgk787.NS_WorkDescription as text;


DROP DOMAIN IF EXISTS mgk787.NS_WorkPhysicalProperty CASCADE;
CREATE DOMAIN mgk787.NS_WorkPhysicalProperty as varchar(30);
--Commented out by sam because my physical properties aren’t in here
--CHECK (VALUE  IN ('Metalwork', 'Furniture', 'Carving', 'Ceramics', 'Painting', 'Textile', ‘Sculpture’, 'Electrical', 'Mechanical'));


DROP DOMAIN IF EXISTS mgk787.NS_WorkClassification CASCADE;
CREATE DOMAIN mgk787.NS_WorkClassification as varchar(30);


-- Sam added this because he was losing a lot of data from csonverting to dates
DROP DOMAIN IF EXISTS mgk787.NS_WorkCreationTimePeriod CASCADE;
CREATE DOMAIN mgk787.NS_WorkCreationTimePeriod as varchar(40);


--Set as varchar(40) instead!!! Dates give huge problem.
DROP DOMAIN IF EXISTS mgk787.NS_WorkCreationDate CASCADE;
CREATE DOMAIN mgk787.NS_WorkCreationDate as DATE;


DROP DOMAIN IF EXISTS mgk787.NS_WorkCreator CASCADE;
CREATE DOMAIN mgk787.NS_WorkCreator as varchar(50);


DROP DOMAIN IF EXISTS mgk787.NS_WorkMedium CASCADE;
CREATE DOMAIN mgk787.NS_WorkMedium as varchar(40);


DROP DOMAIN IF EXISTS mgk787.NS_LocationName CASCADE;
CREATE DOMAIN mgk787.NS_LocationName as varchar(50);


DROP DOMAIN IF EXISTS mgk787.NS_MuseumName CASCADE;
CREATE DOMAIN mgk787.NS_MuseumName as varchar(50);


DROP DOMAIN IF EXISTS mgk787.NS_WorkInsureValue CASCADE;
CREATE DOMAIN mgk787.NS_WorkInsureValue as float
CHECK (VALUE > 0);


DROP DOMAIN IF EXISTS mgk787.NS_OwnerName CASCADE;
CREATE DOMAIN mgk787.NS_OwnerName as varchar(50);


DROP DOMAIN IF EXISTS mgk787.NS_OwnerEmail CASCADE;
CREATE DOMAIN mgk787.NS_OwnerEmail as varchar(80);


DROP DOMAIN IF EXISTS mgk787.NS_OwnershipDate CASCADE;
CREATE DOMAIN mgk787.NS_OwnershipDate as timestamp;

DROP DOMAIN IF EXISTS mgk787.NS_PhoneNumber CASCADE;
CREATE DOMAIN mgk787.NS_PhoneNumber as varchar(13);


DROP DOMAIN IF EXISTS mgk787.NS_LocationSuggestedCapacity CASCADE;
CREATE DOMAIN mgk787.NS_LocationSuggestedCapacity as int;


DROP DOMAIN IF EXISTS mgk787.NS_LocationMeasurement CASCADE;
CREATE DOMAIN mgk787.NS_LocationMeasurement as float
CHECK (VALUE > 0);


DROP DOMAIN IF EXISTS mgk787.NS_WorkTime CASCADE;
CREATE DOMAIN mgk787.NS_WorkTime as timestamp;


DROP DOMAIN IF EXISTS mgk787.NS_ExhibitName CASCADE;
CREATE DOMAIN mgk787.NS_ExhibitName as varchar(150);


DROP DOMAIN IF EXISTS mgk787.NS_InsureDate CASCADE;
CREATE DOMAIN mgk787.NS_InsureDate as timestamp;


DROP DOMAIN IF EXISTS mgk787.NS_ExhibitDescription CASCADE;
CREATE DOMAIN mgk787.NS_ExhibitDescription as text;


DROP DOMAIN IF EXISTS mgk787.NS_ExhibitDate CASCADE;
CREATE DOMAIN mgk787.NS_ExhibitDate as date;
DROP DOMAIN IF EXISTS mgk787.NS_TransactionType CASCADE;
CREATE DOMAIN mgk787.NS_TransactionType as varchar(25)
CHECK (VALUE IN ('Purchased', 'Sold', 'Loaned', 'Borrowed', 'Returned', 'Missing', 'Destroyed', 'Sent for Repairs or Restoration'));


DROP DOMAIN IF EXISTS mgk787.NS_TransactionTime CASCADE;
CREATE DOMAIN mgk787.NS_TransactionTime as timestamp;


DROP DOMAIN IF EXISTS mgk787.NS_WorkBorrowable CASCADE;
CREATE DOMAIN mgk787.NS_WorkBorrowable as boolean;


DROP DOMAIN IF EXISTS mgk787.NS_SecurityName CASCADE;
CREATE DOMAIN mgk787.NS_SecurityName as varchar(75);


DROP DOMAIN IF EXISTS mgk787.NS_ExhibitArrivalDate CASCADE;
CREATE DOMAIN mgk787.NS_ExhibitArrivalDate as timestamp;


DROP DOMAIN IF EXISTS mgk787.NS_ExhibitDepartureDate CASCADE;
CREATE DOMAIN mgk787.NS_ExhibitDepartureDate as timestamp;


DROP DOMAIN IF EXISTS mgk787.NS_DestinationPhone CASCADE;
CREATE DOMAIN mgk787.NS_DestinationPhone as bigint
CHECK (VALUE > 0);


DROP DOMAIN IF EXISTS mgk787.NS_SponsorName CASCADE;
CREATE DOMAIN mgk787.NS_SponsorName as varchar(70);




DROP DOMAIN IF EXISTS mgk787.NS_SponsorAmount CASCADE;
CREATE DOMAIN mgk787.NS_SponsorAmount as float
CHECK (VALUE > 0);


DROP DOMAIN IF EXISTS mgk787.NS_Theme CASCADE;
CREATE DOMAIN mgk787.NS_Theme as varchar(60);


DROP DOMAIN IF EXISTS mgk787.NS_GeographicRegion CASCADE;
CREATE DOMAIN mgk787.NS_GeographicRegion as varchar(100);


DROP DOMAIN IF EXISTS mgk787.NS_Requirements CASCADE;
CREATE DOMAIN mgk787.NS_Requirements as text;


DROP DOMAIN IF EXISTS mgk787.NS_ExhibitArrivalDate CASCADE;
CREATE DOMAIN mgk787.NS_ExhibitArrivalDate as timestamp;


DROP DOMAIN IF EXISTS mgk787.NS_GeographicRegionOfOrigin CASCADE;
CREATE DOMAIN mgk787.NS_GeographicRegionOfOrigin as varchar(100);


DROP DOMAIN IF EXISTS mgk787.NS_CountryOfOrigin CASCADE;
CREATE DOMAIN mgk787.NS_CountryOfOrigin AS varchar(70);


DROP DOMAIN IF EXISTS mgk787.NS_FieldOfScience CASCADE;
CREATE DOMAIN mgk787.NS_FieldOfScience as varchar(70);


DROP DOMAIN IF EXISTS mgk787.NS_Requirements CASCADE;
CREATE DOMAIN mgk787.NS_Requirements as text;


DROP DOMAIN IF EXISTS mgk787.NS_IsTravellingExhibition CASCADE;
CREATE DOMAIN mgk787.NS_IsTravellingExhibition AS boolean;


DROP DOMAIN IF EXISTS mgk787.NS_DateWorkAdded CASCADE;
CREATE DOMAIN mgk787.NS_DateWorkAdded AS DATE;


DROP DOMAIN IF EXISTS mgk787.NS_DateWorkRemoved CASCADE;
CREATE DOMAIN mgk787.NS_DateWorkRemoved AS DATE;


DROP DOMAIN IF EXISTS mgk787.NS_IsPartnerMuseum CASCADE;
CREATE DOMAIN mgk787.NS_IsPartnerMuseum AS boolean;


DROP DOMAIN IF EXISTS mgk787.NS_OwnerCity CASCADE;
CREATE DOMAIN mgk787.NS_OwnerCity AS Varchar(60);


DROP DOMAIN IF EXISTS mgk787.NS_OwnerState CASCADE;
CREATE DOMAIN mgk787.NS_OwnerState AS Varchar(60);


DROP DOMAIN IF EXISTS mgk787.NS_OwnerStreetName CASCADE;
CREATE DOMAIN mgk787.NS_OwnerStreetName AS Varchar(60);


DROP DOMAIN IF EXISTS mgk787.NS_OwnerBuildingNumber CASCADE;
CREATE DOMAIN mgk787.NS_OwnerBuildingNumber AS BIGINT
CHECK (VALUE > 0);


DROP DOMAIN IF EXISTS mgk787.NS_IsTravellingExhibitionLocation CASCADE;
CREATE DOMAIN mgk787.NS_IsTravellingExhibitionLocation boolean;


DROP DOMAIN IF EXISTS mgk787.NS_LocationDate CASCADE;
CREATE DOMAIN mgk787.NS_LocationDate AS DATE;
