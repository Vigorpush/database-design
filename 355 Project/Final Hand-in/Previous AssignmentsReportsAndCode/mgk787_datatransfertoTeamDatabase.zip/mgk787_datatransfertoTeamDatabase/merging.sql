
\i 'domains.sql'
\i 'tables.sql'
\i 'views.sql'


-- upload all textfile into to the new schema mgk787.
\copy mgk787.NS_Owners FROM 'file1.txt'
\copy mgk787.NS_Works FROM 'file2.txt'
\copy mgk787.NS_Locations FROM 'file3.txt'   
\copy mgk787.NS_WorksMedium FROM 'file4.txt'
\copy mgk787.NS_Doors FROM 'file5.txt'
\copy mgk787.NS_Exhibitions FROM 'file6.txt'
\copy mgk787.NS_WorkLocations FROM 'file7.txt'
\copy mgk787.NS_ExhibitionLocations FROM 'file8.txt'
\copy mgk787.NS_ExhibitionWorks FROM 'file9.txt'
\copy mgk787.NS_WorkOwners FROM 'file10.txt'
\copy mgk787.NS_WorkTransaction FROM 'file11.txt'
\copy mgk787.NS_SponsorExhibitions FROM 'file12.txt'
\copy mgk787.NS_WorksInsurance FROM 'file14.txt'



