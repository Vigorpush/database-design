-- Tables google drive. 

DROP table if exists mgk787.NS_WorksInsurance cascade;
DROP table if exists mgk787.NS_Themes cascade; 
DROP table if exists mgk787.NS_SponsorExhibitions cascade;
DROP table if exists mgk787.NS_WorkTransaction cascade;
DROP table if exists mgk787.NS_ExhibitionLocations cascade;
DROP table if exists mgk787.NS_ExhibitionWorks cascade;
DROP table if exists mgk787.NS_WorkOwners cascade;
DROP table if exists mgk787.NS_WorksMedium cascade;
DROP table if exists mgk787.NS_Works cascade;
DROP table if exists mgk787.NS_Owners cascade;
DROP table if exists mgk787.NS_Locations cascade;
DROP table if exists mgk787.NS_Exhibitions cascade;
DROP table if exists mgk787.NS_Doors cascade;
DROP table if exists mgk787.NS_WorkLocations cascade;




-- Done entry
CREATE TABLE mgk787.NS_Owners (
        ownName mgk787.NS_OwnerName NOT NULL,
        ownEmail mgk787.NS_OwnerEmail,
        ownCity mgk787.NS_OwnerCity,
        ownState mgk787.NS_OwnerState,
        ownStreetName mgk787.NS_OwnerStreetName,
        ownBuildingNumber mgk787.NS_OwnerBuildingNumber,
        ownphonenumber	mgk787.NS_PhoneNumber,
        ownisPartnerMuseum mgk787.NS_IsPartnerMuseum NOT NULL,
        PRIMARY KEY(ownName)
);


-- Done entry
CREATE TABLE mgk787.NS_Works (
    worWorkCharID mgk787.NS_WorkCharID NOT NULL,
    worWorkNumID mgk787.NS_WorkNumID NOT NULL,
    worDatabaseEntryMuseum mgk787.NS_OwnerName NOT NULL,
    worWorkName mgk787.NS_WorkName,
    worWorkPhysicalProperty mgk787.NS_WorkPhysicalProperty,
    worWorkClassification mgk787.NS_WorkClassification,
    worWorkCreator mgk787.NS_WorkCreator,
    worWorkCreationDate mgk787.NS_WorkCreationDate,
    worWorkBorrowable mgk787.NS_WorkBorrowable NOT NULL,        
    worWorkGeographicRegionOfOrigin mgk787.NS_GeographicRegionOfOrigin,
    worWorkCountryOfOrigin mgk787.NS_CountryOfOrigin,
    worWorkFieldOfScience mgk787.NS_FieldOfScience,
    worWorkDescription mgk787.NS_WorkDescription,     
    PRIMARY KEY(worWorkCharID, worWorkNumID, worDatabaseEntryMuseum),
    FOREIGN KEY(worDatabaseEntryMuseum) REFERENCES mgk787.NS_Owners(ownName) ON UPDATE CASCADE
);




-- Done entry
CREATE TABLE mgk787.NS_WorksMedium (
    wmeWorkCharID mgk787.NS_WorkCharID NOT NULL,        
    wmeWorkNumID mgk787.NS_WorkNumID NOT NULL,
    wmeDatabaseEntryMuseum mgk787.NS_OwnerName NOT NULL,  
    wmeWorkMedium mgk787.NS_WorkMedium NOT NULL,
    PRIMARY KEY(wmeWorkCharID, wmeWorkNumID, wmeDatabaseEntryMuseum, wmeWorkMedium),
    FOREIGN KEY(wmeWorkCharID, wmeWorkNumID, wmeDatabaseEntryMuseum) REFERENCES mgk787.NS_Works(worWorkCharID, worWorkNumID, worDatabaseEntryMuseum) ON UPDATE CASCADE
);


-- Done entry 
CREATE TABLE mgk787.NS_Locations (
	locLocationName mgk787.NS_LocationName,	
	locOwnerName mgk787.NS_OwnerName,	
	locIsTravellingExhibitionLocation mgk787.NS_IsTravellingExhibitionLocation,
	locLocationSuggestedCapacityMin mgk787.NS_LocationSuggestedCapacity,
	locLocationSuggestedCapacityMax mgk787.NS_LocationSuggestedCapacity,
	locLocationMeasurementWidth mgk787.NS_LocationMeasurement,
	locLocationMeasurementLength mgk787.NS_LocationMeasurement,
	FOREIGN KEY(locOwnerName) REFERENCES mgk787.NS_Owners(ownName),
	PRIMARY KEY(locLocationName, locOwnerName),
CHECK(locLocationSuggestedCapacityMin < locLocationSuggestedCapacityMax)
);



-- Done entry 
CREATE TABLE mgk787.NS_WorkLocations (
	wolWorkCharID mgk787.NS_WorkCharID NOT NULL,
	wolWorkNumID mgk787.NS_WorkNumID NOT NULL,
	wolWorkDatabaseEntryMuseum mgk787.NS_OwnerName NOT NULL,
	wolLocationName mgk787.NS_LocationName NOT NULL,
	wolMuseumName mgk787.NS_OwnerName NOT NULL,
	wolWorkTimeArrival mgk787.NS_WorkTime NOT NULL,
	wolWorkTimeDeparture mgk787.NS_WorkTime,
	Foreign Key (wolWorkCharID, wolWorkNumID, wolWorkDatabaseEntryMuseum) REFERENCES mgk787.NS_Works(worWorkCharID, worWorkNumID, worDatabaseEntryMuseum),
	Foreign Key (wolLocationName, wolMuseumName) REFERENCES mgk787.NS_Locations(locLocationName, locOwnerName),
	PRIMARY KEY(wolWorkCharID, wolWorkNumID, wolWorkDatabaseEntryMuseum, wolLocationName, wolMuseumName,wolWorkTimeArrival),
CHECK ((wolWorkTimeArrival<=wolWorkTimeDeparture) OR (wolWorkTimeDeparture is NULL))
);



-- Done entry
CREATE TABLE mgk787.NS_Doors (
	dorMuseumNameOrigin mgk787.NS_OwnerName NOT NULL,
	dorLocationNameOrigin mgk787.NS_LocationName NOT NULL,
	dorMuseumNameDestination mgk787.NS_OwnerName NOT NULL,    
	dorLocationNameDestination mgk787.NS_LocationName NOT NULL,
	FOREIGN KEY(dorMuseumNameOrigin, dorLocationNameOrigin) REFERENCES mgk787.NS_Locations(locOwnerName, locLocationName),
	FOREIGN KEY(dorMuseumNameDestination, dorLocationNameDestination) REFERENCES mgk787.NS_Locations(locOwnerName, locLocationName),
	PRIMARY KEY(dorMuseumNameOrigin, dorLocationNameOrigin, dorMuseumNameDestination,dorLocationNameDestination)
);


-- Done entry
CREATE TABLE mgk787.NS_Exhibitions (
	exhExhibitName mgk787.NS_ExhibitName NOT NULL,
	exhMuseumName mgk787.NS_OwnerName NOT NULL,
	exhExhibitDateStart mgk787.NS_ExhibitDate NOT NULL,
	exhExhibitDateEnd mgk787.NS_ExhibitDate NOT NULL,
	exhExhibitDescription mgk787.NS_ExhibitDescription,  
	exhSecurityPersonName mgk787.NS_SecurityName,
	exhIsTravellingExhibition mgk787.NS_IsTravellingExhibition,
	PRIMARY KEY(exhExhibitName, exhMuseumName, exhExhibitDateStart),
	FOREIGN KEY(exhMuseumName) REFERENCES mgk787.NS_Owners(OwnName),
CHECK( exhExhibitDateStart<exhExhibitDateEnd)
);


-- Done  entry
CREATE TABLE mgk787.NS_ExhibitionLocations (
	eloExhibitName mgk787.NS_ExhibitName NOT NULL,
	eloExhibitDateStart mgk787.NS_ExhibitDate NOT NULL,
	eloLocationName mgk787.NS_LocationName NOT NULL,
	eloMuseumOfLocation mgk787.NS_OwnerName NOT NULL,
	eloMuseumOfExhibition mgk787.NS_OwnerName NOT NULL,
	eloLocationDateStart mgk787.NS_LocationDate NOT NULL,
	eloLocationDateEnd mgk787.NS_LocationDate,
	PRIMARY KEY(eloExhibitName, eloExhibitDateStart, eloLocationName, eloMuseumOfLocation, eloLocationDateStart),
	FOREIGN KEY(eloExhibitname, eloExhibitDateStart,eloMuseumOfExhibition) REFERENCES mgk787.NS_Exhibitions(exhExhibitName, exhExhibitDateStart, exhMuseumName),
	FOREIGN KEY(eloLocationName, eloMuseumOfLocation) REFERENCES mgk787.NS_Locations(locLocationName, locOwnerName),
    	CHECK(((eloLocationDateEnd is NULL) OR (eloLocationDateStart<eloLocationDateEnd))
            	AND (eloExhibitDateStart<=eloLocationDateStart))
);

-- Done entry
CREATE TABLE mgk787.NS_ExhibitionWorks (
	exwExhibitName mgk787.NS_ExhibitName NOT NULL,
	exwExhibitDateStart mgk787.NS_ExhibitDate NOT NULL,
	exwMuseumOfExhibition mgk787.NS_OwnerName NOT NULL,
	exwWorkCharID mgk787.NS_WorkCharID NOT NULL,
	exwWorkNumID mgk787.NS_WorkNumID NOT NULL,
	exwWorkDataBaseEntryMuseum mgk787.NS_OwnerName NOT NULL,
	exwDateWorkAdded mgk787.NS_DateWorkAdded NOT NULL,
	exwDateWorkRemoved mgk787.NS_DateWorkRemoved,
	PRIMARY KEY(exwExhibitname, exwExhibitDateStart, exwMuseumOfExhibition, exwWorkCharID, exwWorkNumID, exwWorkDataBaseEntryMuseum, exwDateWorkAdded),
	FOREIGN KEY(exwExhibitName, exwExhibitDateStart,exwMuseumOfExhibition) REFERENCES mgk787.NS_Exhibitions(exhExhibitName,exhExhibitDateStart, exhMuseumName),
	FOREIGN KEY(exwWorkCharID, exwWorkNumID, exwWorkDatabaseEntryMuseum) REFERENCES mgk787.NS_Works(worWorkCharID, worWorkNumID, worDatabaseEntryMuseum),
    	CHECK((exwDateWorkAdded<exwDateWorkRemoved) OR (exwDateWorkRemoved is NULL))
);

-- Done entry
CREATE TABLE mgk787.NS_WorkOwners (
    wonWorkCharID mgk787.NS_WorkCharID NOT NULL,
    wonWorkNumID mgk787.NS_WorkNumID NOT NULL,
    wonWorkDatabaseEntryMuseum mgk787.NS_OwnerName NOT NULL,
    wonOwnerName mgk787.NS_OwnerName NOT NULL,
    wonOwnershipDateStart mgk787.NS_OwnershipDate NOT NULL,
    wonOwnershipDateEnd mgk787.NS_OwnershipDate,
    PRIMARY KEY(wonWorkCharID, wonWorkNumId, wonWorkDatabaseEntryMuseum, wonOwnerName, wonOwnershipDateStart),
    FOREIGN KEY(wonWorkCharID, wonWorkNumID, wonWorkDatabaseEntryMuseum) REFERENCES mgk787.NS_Works(worWorkCharID, worWorkNumID, worDatabaseEntryMuseum),
    FOREIGN KEY(wonOwnerName) REFERENCES mgk787.NS_Owners(ownName),
        CHECK((wonOwnershipDateStart<wonOwnershipDateEnd) OR (wonOwnershipDateEnd is NULL))
);


-- Done entry
CREATE TABLE mgk787.NS_WorkTransaction (
	wtrWorkCharID mgk787.NS_WorkCharID NOT NULL,
	wtrWorkNumID mgk787.NS_WorkNumID NOT NULL,
	wtrWorkDatabaseEntryMuseum mgk787.NS_OwnerName NOT NULL,
	wtrMuseumInvolved mgk787.NS_OwnerName NOT NULL,
	wtrClient mgk787.NS_OwnerName,
	wtrTransactiontype mgk787.NS_TransactionType NOT NULL,
	wtrTransactionTime mgk787.NS_TransactionTime NOT NULL,
	PRIMARY KEY(wtrWorkCharID, wtrWorkNumID, wtrWorkDatabaseEntryMuseum, wtrMuseumInvolved, wtrTransactionType, wtrTransactionTime),
	FOREIGN KEY(wtrWorkCharID, wtrWorkNumID, wtrWorkDatabaseEntryMuseum) REFERENCES mgk787.NS_Works(worWorkCharID, worWorkNumID, worDatabaseEntryMuseum),
	FOREIGN KEY(wtrWorkDatabaseEntryMuseum) REFERENCES mgk787.NS_Owners(ownName),
	FOREIGN KEY(wtrClient) REFERENCES mgk787.NS_Owners(ownName)
);


-- Done entry
CREATE TABLE mgk787.NS_SponsorExhibitions (
	speSponsorName mgk787.NS_SponsorName NOT NULL,
	speExhibitName mgk787.NS_ExhibitName NOT NULL,
	speMuseumName mgk787.NS_OwnerName NOT NULL,
	speExhibitDateStart mgk787.NS_ExhibitDate NOT NULL,
	speSponsorAmount mgk787.NS_SponsorAmount,
	PRIMARY KEY(speSponsorName, speExhibitName, speMuseumName, speExhibitDateStart),
	FOREIGN KEY(speExhibitName, speMuseumName, speExhibitDateStart) REFERENCES mgk787.NS_Exhibitions(exhExhibitName, exhMuseumName, exhExhibitDateStart)
);


-- Done
CREATE TABLE mgk787.NS_Themes (
	wthWorkCharID mgk787.NS_WorkCharID NOT NULL,
	wthWorkNumID mgk787.NS_WorkNumID NOT NULL,
	wthWorkDatabaseEntryMuseum mgk787.NS_OwnerName NOT NULL,
	wthTheme mgk787.NS_Theme NOT NULL,
	PRIMARY KEY(wthWorkCharID, wthWorkNumID, wthWorkDatabaseEntryMuseum, wthTheme),
	FOREIGN KEY(wthWorkCharID, wthWorkNumID, wthWorkDatabaseEntryMuseum) REFERENCES mgk787.NS_Works(worWorkCharID, worWorkNumID, worDatabaseEntryMuseum)
);


-- Done entry
CREATE TABLE mgk787.NS_WorksInsurance (
	winWorkCharID mgk787.NS_WorkCharID NOT NULL,
	winWorkNumID mgk787.NS_WorkNumID NOT NULL,
	winWorkDatabaseEntryMuseum mgk787.NS_OwnerName NOT NULL,
	winWorkInsureValue mgk787.NS_WorkInsureValue NOT NULL,
	winInsureDateStart mgk787.NS_InsureDate NOT NULL,
	winInsureDateEnd mgk787.NS_InsureDate,
	PRIMARY KEY(winWorkCharID, winWorkNumID, winWorkDatabaseEntryMuseum, winInsureDateStart),
	FOREIGN KEY(winWorkCharID, winWorkNumID, winWorkDatabaseEntryMuseum) REFERENCES mgk787.NS_Works(worWorkCharID, worWorkNumID, worDatabaseEntryMuseum),
CHECK((winInsureDateStart< winInsureDateEnd) OR (winInsureDateEnd is NULL))
);


